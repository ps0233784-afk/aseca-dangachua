# BRANCH ASECA DANGACHUA - Premium Educational Website

A production-ready, fully functional premium Educational Institution Website and Management System with neon-glassmorphism design and Santali cultural identity.

## Tech Stack

- **Frontend**: React.js, Vite, Tailwind CSS, Framer Motion, Swiper.js, Recharts
- **Backend**: Firebase (Authentication, Firestore, Storage)
- **Deployment**: Netlify (Frontend) + Firebase (Backend)

## Quick Start

1. **Install dependencies**
2. **Configure Firebase**
   - Create a Firebase project at [console.firebase.google.com](https://console.firebase.google.com)
   - Enable Authentication (Email/Password), Firestore, and Storage
   - Copy your config values to `.env` (see `.env.example`)

3. **Deploy Firebase Rules**
   ```bash
   firebase deploy --only firestore:rules,storage
   ```

4. **Run locally**
   ```bash
   npm run dev
   ```

5. **Build for production**
   ```bash
   npm run build
   ```

## Deploy to Netlify

1. Push this repository to GitHub
2. In Netlify, create a new site from Git
3. Set build command: `npm run build`
4. Set publish directory: `dist`
5. Add your Firebase environment variables in Netlify settings
6. Deploy!

## Admin Setup

1. Create a user in Firebase Authentication
2. In Firestore, create a document in `users` collection:
   ```json
   {
     "email": "admin@asecadangachua.edu.in",
     "name": "Admin",
     "role": "superadmin",
     "active": true
   }
   ```
3. Login at `/admin/login`

## Features

- ✅ Cinematic landing page with Santali cultural hero
- ✅ Neon + Glassmorphism premium design
- ✅ Full admin dashboard with content editors
- ✅ Schools, Teachers, Students management
- ✅ Teacher attendance system
- ✅ Examination & Result portal with QR verification
- ✅ Digital library with file uploads
- ✅ News & Events management
- ✅ Photo gallery with lightbox
- ✅ Santali culture page
- ✅ Contact form with message management
- ✅ Role-based access control (Super Admin, Admin, Editor, Viewer)
- ✅ Firebase security rules
- ✅ Responsive design for all devices
- ✅ SEO optimized

## Project Structure

```
src/
 ├── components/     # Reusable components
 ├── pages/          # Public pages
 ├── admin/          # Admin pages
 ├── layouts/        # Layouts
 ├── hooks/          # Custom hooks
 ├── services/       # Firebase services
 ├── firebase/       # Firebase config
 ├── utils/          # Helper functions
 ├── assets/         # Static assets
 ├── styles/         # Global styles
 └── App.jsx         # Main app
```

## License

MIT