export const formatDate = (date) => {
  if (!date) return 'N/A'
  try {
    const d = date?.seconds ? new Date(date.seconds * 1000) : new Date(date)
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
  } catch {
    return 'N/A'
  }
}

export const formatDateTime = (date) => {
  if (!date) return 'N/A'
  try {
    const d = date?.seconds ? new Date(date.seconds * 1000) : new Date(date)
    return d.toLocaleString('en-IN', {
      day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
    })
  } catch {
    return 'N/A'
  }
}

export const toTimestamp = (date) => {
  return new Date(date)
}

export const isValidEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return re.test(email)
}

export const truncate = (str, len = 100) => {
  if (!str) return ''
  return str.length > len ? str.substring(0, len) + '...' : str
}

export const calculateAge = (dob) => {
  if (!dob) return 'N/A'
  const birth = dob?.seconds ? new Date(dob.seconds * 1000) : new Date(dob)
  const diff = Date.now() - birth.getTime()
  const age = new Date(diff).getUTCFullYear() - 1970
  return age
}

export const calculatePercentage = (marks, total) => {
  if (!total) return 0
  return ((marks / total) * 100).toFixed(2)
}

export const calculateGrade = (percentage) => {
  if (percentage >= 90) return 'A+'
  if (percentage >= 80) return 'A'
  if (percentage >= 70) return 'B+'
  if (percentage >= 60) return 'B'
  if (percentage >= 50) return 'C'
  if (percentage >= 40) return 'D'
  return 'F'
}

export const generateStudentId = (year, schoolCode = 'ASE') => {
  const y = year || new Date().getFullYear()
  const rand = Math.floor(1000 + Math.random() * 9000)
  return `${schoolCode}-${y}-${rand}`
}

export const downloadTextFile = (filename, content) => {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

export const downloadJSON = (filename, data) => {
  downloadTextFile(filename, JSON.stringify(data, null, 2))
}

export const classNames = (...classes) => {
  return classes.filter(Boolean).join(' ')
}

export const getErrorMessage = (error) => {
  if (!error) return 'An error occurred'
  if (error.code === 'auth/wrong-password') return 'Incorrect password. Please try again.'
  if (error.code === 'auth/user-not-found') return 'No account found with this email.'
  if (error.code === 'auth/invalid-email') return 'Please enter a valid email address.'
  if (error.code === 'auth/email-already-in-use') return 'This email is already registered.'
  if (error.code === 'auth/weak-password') return 'Password should be at least 6 characters.'
  if (error.code === 'auth/network-request-failed') return 'Network error. Check your connection.'
  if (error.message) return error.message
  return 'An unexpected error occurred'
}

export default {
  formatDate,
  formatDateTime,
  isValidEmail,
  truncate,
  calculateAge,
  calculatePercentage,
  calculateGrade,
  generateStudentId,
  downloadTextFile,
  downloadJSON,
  classNames,
  getErrorMessage
}