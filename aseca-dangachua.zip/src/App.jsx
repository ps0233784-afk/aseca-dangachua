import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './contexts/AuthContext'
import { Loader } from './components/ui'
import PublicLayout from './layouts/PublicLayout'
import AdminLayout from './layouts/AdminLayout'

// Public pages
import Home from './pages/Home'
import About from './pages/About'
import ManagingBody from './pages/ManagingBody'
import Schools from './pages/Schools'
import Teachers from './pages/Teachers'
import Students from './pages/Students'
import Attendance from './pages/Attendance'
import Examinations from './pages/Examinations'
import Results from './pages/Results'
import Library from './pages/Library'
import News from './pages/News'
import Gallery from './pages/Gallery'
import Culture from './pages/Culture'
import Contact from './pages/Contact'

// Admin pages
import AdminLogin from './pages/admin/AdminLogin'
import AdminDashboard from './pages/admin/AdminDashboard'
import AdminHomepage from './pages/admin/AdminHomepage'
import AdminAbout from './pages/admin/AdminAbout'
import AdminManagingBody from './pages/admin/AdminManagingBody'
import AdminSchools from './pages/admin/AdminSchools'
import AdminTeachers from './pages/admin/AdminTeachers'
import AdminAttendance from './pages/admin/AdminAttendance'
import AdminStudents from './pages/admin/AdminStudents'
import AdminExaminations from './pages/admin/AdminExaminations'
import AdminResults from './pages/admin/AdminResults'
import AdminLibrary from './pages/admin/AdminLibrary'
import AdminNews from './pages/admin/AdminNews'
import AdminGallery from './pages/admin/AdminGallery'
import AdminCulture from './pages/admin/AdminCulture'
import AdminMessages from './pages/admin/AdminMessages'
import AdminMedia from './pages/admin/AdminMedia'
import AdminSettings from './pages/admin/AdminSettings'
import AdminUsers from './pages/admin/AdminUsers'

function ProtectedRoute({ children }) {
  const { isAdmin, loading } = useAuth()
  if (loading) return <Loader fullScreen />
  if (!isAdmin) return <Navigate to="/admin/login" replace />
  return children
}

export default function App() {
  return (
    <Routes>
      {/* Public routes */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/managing-body" element={<ManagingBody />} />
        <Route path="/schools" element={<Schools />} />
        <Route path="/teachers" element={<Teachers />} />
        <Route path="/students" element={<Students />} />
        <Route path="/attendance" element={<Attendance />} />
        <Route path="/examinations" element={<Examinations />} />
        <Route path="/results" element={<Results />} />
        <Route path="/library" element={<Library />} />
        <Route path="/news" element={<News />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/culture" element={<Culture />} />
        <Route path="/contact" element={<Contact />} />
      </Route>

      {/* Admin routes */}
      <Route path="/admin/login" element={<AdminLogin />} />
      <Route path="/admin" element={<ProtectedRoute><AdminLayout /></ProtectedRoute>}>
        <Route index element={<Navigate to="/admin/dashboard" replace />} />
        <Route path="dashboard" element={<AdminDashboard />} />
        <Route path="homepage" element={<AdminHomepage />} />
        <Route path="about" element={<AdminAbout />} />
        <Route path="managing-body" element={<AdminManagingBody />} />
        <Route path="schools" element={<AdminSchools />} />
        <Route path="teachers" element={<AdminTeachers />} />
        <Route path="attendance" element={<AdminAttendance />} />
        <Route path="students" element={<AdminStudents />} />
        <Route path="examinations" element={<AdminExaminations />} />
        <Route path="results" element={<AdminResults />} />
        <Route path="library" element={<AdminLibrary />} />
        <Route path="news" element={<AdminNews />} />
        <Route path="gallery" element={<AdminGallery />} />
        <Route path="culture" element={<AdminCulture />} />
        <Route path="messages" element={<AdminMessages />} />
        <Route path="media" element={<AdminMedia />} />
        <Route path="settings" element={<AdminSettings />} />
        <Route path="users" element={<AdminUsers />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}