import {
  collection,
  doc,
  getDocs,
  getDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore'
import { db } from '../firebase/firestore'

// Generic collection helpers
export const getCollection = (name, constraints = []) => {
  return getDocs(query(collection(db, name), ...constraints))
}

export const getDocument = (name, id) => {
  return getDoc(doc(db, name, id))
}

export const addDocument = async (name, data) => {
  const ref = await addDoc(collection(db, name), {
    ...data,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  })
  return ref
}

export const updateDocument = async (name, id, data) => {
  await updateDoc(doc(db, name, id), {
    ...data,
    updatedAt: serverTimestamp()
  })
}

export const deleteDocument = async (name, id) => {
  await deleteDoc(doc(db, name, id))
}

// Real-time subscription
export const subscribeToCollection = (name, callback, constraints = []) => {
  return onSnapshot(query(collection(db, name), ...constraints), (snapshot) => {
    const data = []
    snapshot.forEach(doc => {
      data.push({ id: doc.id, ...doc.data() })
    })
    callback(data)
  })
}

// Specific helpers
export const getPublished = (name) => {
  return getCollection(name, [
    where('published', '==', true),
    orderBy('createdAt', 'desc')
  ])
}

export const getByField = (name, field, value) => {
  return getCollection(name, [where(field, '==', value)])
}

export const getUsers = () => {
  return getCollection('users')
}

export const getUserByEmail = (email) => {
  return getCollection('users', [where('email', '==', email), limit(1)])
}

export default {
  getCollection,
  getDocument,
  addDocument,
  updateDocument,
  deleteDocument,
  subscribeToCollection,
  getPublished,
  getByField,
  getUsers,
  getUserByEmail
}