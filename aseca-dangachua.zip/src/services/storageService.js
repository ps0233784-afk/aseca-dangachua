import {
  ref,
  uploadBytes as fbUploadBytes,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
  listAll
} from 'firebase/storage'
import { storage } from '../firebase/storage'

const MAX_SIZE = 10 * 1024 * 1024 // 10MB

export const validateFile = (file, allowedTypes = ['image/*', 'application/pdf']) => {
  if (file.size > MAX_SIZE) {
    return { valid: false, error: `File too large. Maximum size is ${MAX_SIZE / (1024 * 1024)}MB.` }
  }

  const isAllowed = allowedTypes.some(type => {
    if (type.endsWith('/*')) {
      return file.type.startsWith(type.slice(0, -1))
    }
    return file.type === type
  })

  if (!isAllowed) {
    return { valid: false, error: 'Invalid file type. Please upload an image or PDF.' }
  }

  return { valid: true }
}

export const uploadFile = (path, file, onProgress) => {
  const storageRef = ref(storage, path)
  const uploadTask = uploadBytesResumable(storageRef, file)

  return new Promise((resolve, reject) => {
    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100
        if (onProgress) onProgress(progress)
      },
      (error) => reject(error),
      async () => {
        const url = await getDownloadURL(uploadTask.snapshot.ref)
        resolve({ url, path: uploadTask.snapshot.ref.fullPath })
      }
    )
  })
}

export const uploadBytes = async (path, data, metadata) => {
  const storageRef = ref(storage, path)
  await fbUploadBytes(storageRef, data, metadata)
  return getDownloadURL(storageRef)
}

export const deleteFile = async (path) => {
  const storageRef = ref(storage, path)
  try {
    await deleteObject(storageRef)
    return true
  } catch (error) {
    console.error('Delete failed:', error)
    return false
  }
}

export const getFileUrl = async (path) => {
  const storageRef = ref(storage, path)
  return getDownloadURL(storageRef)
}

export const listFiles = async (folder) => {
  const folderRef = ref(storage, folder)
  const res = await listAll(folderRef)
  const urls = await Promise.all(res.items.map(item => getDownloadURL(item)))
  return res.items.map((item, i) => ({ name: item.name, url: urls[i], path: item.fullPath }))
}

export default {
  uploadFile,
  uploadBytes,
  deleteFile,
  getFileUrl,
  listFiles,
  validateFile
}