import { addDocument } from './firestoreService'

export const logAudit = async (user, action, details = {}) => {
  try {
    await addDocument('auditLogs', {
      userEmail: user?.email || 'unknown',
      userRole: user?.role || 'unknown',
      action,
      details,
      timestamp: new Date().toISOString()
    })
  } catch (error) {
    console.error('Audit log failed:', error)
  }
}

export default { logAudit }