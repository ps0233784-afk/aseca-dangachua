import { useState, useEffect } from 'react'
import { getCollection as fetchCollection, subscribeToCollection } from '../services/firestoreService'

export const useCollection = (name, constraints = [], live = false) => {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let unsubscribe = null

    const load = async () => {
      try {
        if (live) {
          unsubscribe = subscribeToCollection(name, (items) => {
            setData(items)
            setLoading(false)
          }, constraints)
        } else {
          const snap = await fetchCollection(name, constraints)
          const items = []
          snap.forEach(doc => items.push({ id: doc.id, ...doc.data() }))
          setData(items)
          setLoading(false)
        }
      } catch (err) {
        console.error(`Error loading ${name}:`, err)
        setError(err)
        setLoading(false)
      }
    }

    const reload = () => {
      setLoading(true)
      load()
    }

    load()

    return () => {
      if (unsubscribe) unsubscribe()
    }
  }, [name, JSON.stringify(constraints), live])

  return { data, loading, error, refetch: () => { setLoading(true); load() } }
}

export default useCollection