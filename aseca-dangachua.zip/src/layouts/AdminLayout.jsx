import { useState, useEffect } from 'react'
import { NavLink, Outlet, useNavigate, Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard, Home, Info, Users, School, GraduationCap, ClipboardCheck,
  UserSquare, FileSpreadsheet, Award, BookOpen, Newspaper, Images, Music,
  Mail, FolderOpen, Settings, LogOut, Menu, X, ChevronRight
} from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { useSettings } from '../contexts/SettingsContext'

const menuItems = [
  { label: 'Dashboard', path: '/admin/dashboard', icon: LayoutDashboard, desc: 'Overview & statistics' },
  { label: 'Homepage Editor', path: '/admin/homepage', icon: Home, desc: 'Edit landing page content' },
  { label: 'About', path: '/admin/about', icon: Info, desc: 'Manage about page' },
  { label: 'Managing Body', path: '/admin/managing-body', icon: Users, desc: 'Manage members' },
  { label: 'Schools', path: '/admin/schools', icon: School, desc: 'Manage schools' },
  { label: 'Teachers', path: '/admin/teachers', icon: GraduationCap, desc: 'Manage teachers' },
  { label: 'Attendance', path: '/admin/attendance', icon: ClipboardCheck, desc: 'Mark attendance' },
  { label: 'Students', path: '/admin/students', icon: UserSquare, desc: 'Manage students' },
  { label: 'Examinations', path: '/admin/examinations', icon: FileSpreadsheet, desc: 'Manage exams' },
  { label: 'Results', path: '/admin/results', icon: Award, desc: 'Manage results' },
  { label: 'Library', path: '/admin/library', icon: BookOpen, desc: 'Library resources' },
  { label: 'News & Events', path: '/admin/news', icon: Newspaper, desc: 'Manage news' },
  { label: 'Gallery', path: '/admin/gallery', icon: Images, desc: 'Manage photos' },
  { label: 'Culture', path: '/admin/culture', icon: Music, desc: 'Culture content' },
  { label: 'Messages', path: '/admin/messages', icon: Mail, desc: 'Contact messages' },
  { label: 'Media', path: '/admin/media', icon: FolderOpen, desc: 'Manage files' },
  { label: 'Settings', path: '/admin/settings', icon: Settings, desc: 'Website settings' }
]

export default function AdminLayout() {
  const { user, userData, logout } = useAuth()
  const { settings } = useSettings()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [mobileSidebar, setMobileSidebar] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setSidebarOpen(true)
        setMobileSidebar(false)
      } else {
        setSidebarOpen(false)
      }
    }
    handleResize()
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  const handleLogout = async () => {
    await logout()
    navigate('/admin/login')
  }

  const sidebarContent = (
    <div className="flex flex-col h-full">
      <div className="p-6">
        <Link to="/" className="flex items-center gap-3">
          {settings.logo ? (
            <img src={settings.logo} alt="Logo" className="h-10 w-10 rounded-lg object-cover" />
          ) : (
            <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-neon-blue to-violet-500 flex items-center justify-center">
              <GraduationCap className="h-6 w-6 text-white" />
            </div>
          )}
          <div>
            <div className="font-display font-bold text-sm neon-text leading-tight">{settings.institutionName}</div>
            <div className="text-[10px] text-gray-500">Admin Dashboard</div>
          </div>
        </Link>
      </div>

      <nav className="flex-1 overflow-y-auto px-4 pb-4 no-scrollbar">
        {menuItems.map(item => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.path === '/admin/dashboard'}
            className={({ isActive }) => `admin-sidebar-link mb-1 ${isActive ? 'active' : ''}`}
            title={item.desc}
          >
            <item.icon className="h-5 w-5 shrink-0" />
            <span className="flex-1">{item.label}</span>
            <ChevronRight className="h-4 w-4 opacity-0 group-hover:opacity-100" />
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-white/10">
        <div className="flex items-center gap-3 px-2 mb-3">
          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-neon-blue to-violet-500 flex items-center justify-center font-bold text-sm">
            {userData?.name?.[0] || user?.email?.[0]?.toUpperCase() || 'A'}
          </div>
          <div className="min-w-0">
            <div className="text-sm font-medium text-white truncate">{userData?.name || user?.email}</div>
            <div className="text-xs text-gray-500 capitalize">{userData?.role || 'user'}</div>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="w-full admin-sidebar-link !text-red-400 hover:!bg-red-500/10"
        >
          <LogOut className="h-5 w-5" />
          <span>Logout</span>
        </button>
        <Link to="/" className="admin-sidebar-link mt-1">
          <Home className="h-5 w-5" />
          <span>View Website</span>
        </Link>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-dark-900">
      {/* Desktop sidebar */}
      {sidebarOpen && (
        <aside className="hidden lg:flex fixed left-0 top-0 bottom-0 w-64 bg-dark-800/95 backdrop-blur-xl border-r border-white/10 z-50 overflow-y-auto no-scrollbar">
          {sidebarContent}
        </aside>
      )}

      {/* Mobile sidebar */}
      <AnimatePresence>
        {mobileSidebar && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
            onClick={() => setMobileSidebar(false)}
          >
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="fixed left-0 top-0 bottom-0 w-72 bg-dark-800/95 backdrop-blur-xl border-r border-white/10 overflow-y-auto no-scrollbar"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setMobileSidebar(false)}
                className="absolute top-4 right-4 p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10"
              >
                <X className="h-5 w-5" />
              </button>
              {sidebarContent}
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main content */}
      <div className={`transition-all duration-300 ${sidebarOpen ? 'lg:pl-64' : 'pl-0'}`}>
        {/* Top bar */}
        <header className="sticky top-0 z-40 bg-dark-900/90 backdrop-blur-xl border-b border-white/10 px-4 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (window.innerWidth >= 1024) {
                  setSidebarOpen(!sidebarOpen)
                } else {
                  setMobileSidebar(!mobileSidebar)
                }
              }}
              className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 lg:hidden"
            >
              <Menu className="h-6 w-6" />
            </button>
            <div className="hidden sm:block">
              <h1 className="font-display font-bold text-white">Admin Dashboard</h1>
              <p className="text-xs text-gray-500">Manage your website content</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/"
              className="hidden sm:inline-flex px-4 py-2 rounded-xl border border-neon-blue/30 text-neon-blue text-sm hover:bg-neon-blue/10 transition-all"
            >
              View Website
            </Link>
            <button
              onClick={handleLogout}
              className="p-2 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
              title="Logout"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </header>

        <main className="p-4 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  )
}