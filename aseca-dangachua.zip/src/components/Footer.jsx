import { Link } from 'react-router-dom'
import { GraduationCap, Mail, Phone, MapPin, Facebook, Instagram, Twitter, Youtube } from 'lucide-react'
import { useSettings } from '../contexts/SettingsContext'

export default function Footer() {
  const { settings } = useSettings()

  const quickLinks = [
    { label: 'Home', path: '/' },
    { label: 'About', path: '/about' },
    { label: 'Managing Body', path: '/managing-body' },
    { label: 'Schools', path: '/schools' },
    { label: 'Teachers', path: '/teachers' },
    { label: 'Students', path: '/students' }
  ]

  const moreLinks = [
    { label: 'Examinations', path: '/examinations' },
    { label: 'Results', path: '/results' },
    { label: 'Library', path: '/library' },
    { label: 'News', path: '/news' },
    { label: 'Gallery', path: '/gallery' },
    { label: 'Culture', path: '/culture' },
    { label: 'Contact', path: '/contact' }
  ]

  const socialLinks = [
    { icon: Facebook, label: 'Facebook', url: settings.socialLinks?.facebook },
    { icon: Instagram, label: 'Instagram', url: settings.socialLinks?.instagram },
    { icon: Twitter, label: 'Twitter', url: settings.socialLinks?.twitter },
    { icon: Youtube, label: 'YouTube', url: settings.socialLinks?.youtube }
  ].filter(s => s.url)

  return (
    <footer className="bg-dark-900 border-t border-white/10 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              {settings.logo ? (
                <img src={settings.logo} alt="Logo" className="h-12 w-12 rounded-lg object-cover" />
              ) : (
                <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-neon-blue to-violet-500 flex items-center justify-center shadow-neon-blue">
                  <GraduationCap className="h-7 w-7 text-white" />
                </div>
              )}
              <div>
                <div className="font-display font-bold text-neon-text">{settings.institutionName}</div>
                <div className="text-xs text-gray-400">{settings.tagline}</div>
              </div>
            </div>
            <p className="text-sm text-gray-400">
              Empowering young minds with quality education while preserving the rich Santali cultural heritage.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-display font-semibold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map(link => (
                <li key={link.path}>
                  <Link to={link.path} className="text-sm text-gray-400 hover:text-neon-blue transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* More Links */}
          <div>
            <h3 className="font-display font-semibold text-white mb-4">Information</h3>
            <ul className="space-y-2">
              {moreLinks.map(link => (
                <li key={link.path}>
                  <Link to={link.path} className="text-sm text-gray-400 hover:text-neon-blue transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-display font-semibold text-white mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-sm text-gray-400">
                <MapPin className="h-5 w-5 text-neon-blue shrink-0 mt-0.5" />
                {settings.address}
              </li>
              <li className="flex items-center gap-3 text-sm text-gray-400">
                <Phone className="h-5 w-5 text-neon-emerald shrink-0" />
                <a href={`tel:${settings.contactPhone}`} className="hover:text-neon-blue">{settings.contactPhone}</a>
              </li>
              <li className="flex items-center gap-3 text-sm text-gray-400">
                <Mail className="h-5 w-5 text-neon-gold shrink-0" />
                <a href={`mailto:${settings.contactEmail}`} className="hover:text-neon-blue">{settings.contactEmail}</a>
              </li>
            </ul>
            {socialLinks.length > 0 && (
              <div className="flex gap-3 mt-4">
                {socialLinks.map((social, i) => (
                  <a
                    key={i}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg bg-white/5 hover:bg-neon-blue/20 hover:text-neon-blue text-gray-400 transition-all"
                  >
                    <social.icon className="h-4 w-4" />
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-6 text-center text-sm text-gray-500">
          {settings.footerText || '© 2025 BRANCH ASECA DANGACHUA. All rights reserved.'}
          <div className="mt-2">
            <Link to="/admin/login" className="text-xs hover:text-neon-blue transition-colors">
              Administrator Login
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}