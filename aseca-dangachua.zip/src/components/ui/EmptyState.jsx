import { Inbox } from 'lucide-react'

export default function EmptyState({ title = 'No items found', description = 'Items will appear here when added.', icon: Icon = Inbox }) {
  return (
    <div className="text-center py-16">
      <div className="inline-flex p-4 rounded-2xl bg-white/5 mb-4">
        <Icon className="h-10 w-10 text-gray-500" />
      </div>
      <h3 className="text-lg font-semibold text-white mb-1">{title}</h3>
      <p className="text-sm text-gray-400">{description}</p>
    </div>
  )
}