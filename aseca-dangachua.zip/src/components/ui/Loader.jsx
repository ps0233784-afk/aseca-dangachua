export default function Loader({ fullScreen = false, text = 'Loading...' }) {
  if (fullScreen) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-dark-900/90 backdrop-blur-md">
        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <div className="h-16 w-16 rounded-full border-2 border-neon-blue/20 border-t-neon-blue animate-spin" />
            <div className="absolute inset-0 h-16 w-16 rounded-full border-2 border-violet-500/20 border-b-violet-500 animate-spin" style={{ animationDirection: 'reverse' }} />
          </div>
          <p className="text-sm text-gray-400">{text}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex items-center justify-center py-12">
      <div className="flex flex-col items-center gap-3">
        <div className="h-10 w-10 rounded-full border-2 border-neon-blue/20 border-t-neon-blue animate-spin" />
        <p className="text-xs text-gray-400">{text}</p>
      </div>
    </div>
  )
}