import { motion } from 'framer-motion'

export default function StatCard({ icon: Icon, label, value, color = 'blue', delay = 0 }) {
  const colors = {
    blue: 'from-neon-blue/20 to-transparent text-neon-blue border-neon-blue/30',
    emerald: 'from-neon-emerald/20 to-transparent text-neon-emerald border-neon-emerald/30',
    violet: 'from-violet-500/20 to-transparent text-violet-400 border-violet-500/30',
    gold: 'from-neon-gold/20 to-transparent text-neon-gold border-neon-gold/30',
    magenta: 'from-neon-magenta/20 to-transparent text-neon-magenta border-neon-magenta/30'
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className={`glass-card p-6 text-center bg-gradient-to-b ${colors[color]}`}
    >
      {Icon && (
        <div className="inline-flex p-3 rounded-xl bg-white/5 mb-3">
          <Icon className="h-6 w-6" />
        </div>
      )}
      <div className="text-3xl font-bold font-display text-white mb-1">{value}</div>
      <div className="text-sm text-gray-400">{label}</div>
    </motion.div>
  )
}