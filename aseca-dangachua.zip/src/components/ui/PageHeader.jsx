import { motion } from 'framer-motion'

export default function PageHeader({ title, subtitle, icon: Icon }) {
  return (
    <div className="relative pt-28 pb-12 px-4 text-center bg-gradient-animated">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {Icon && (
            <div className="inline-flex p-4 rounded-2xl bg-gradient-to-br from-neon-blue/20 to-violet-500/20 border border-white/10 mb-4">
              <Icon className="h-8 w-8 text-neon-blue" />
            </div>
          )}
          <h1 className="text-3xl md:text-5xl font-bold neon-text mb-3">{title}</h1>
          {subtitle && (
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">{subtitle}</p>
          )}
        </motion.div>
      </div>
    </div>
  )
}