import { User } from 'lucide-react'
import { motion } from 'framer-motion'

export default function ProfileCard({
  photo,
  name,
  title,
  subtitle,
  children,
  delay = 0,
  onClick
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      onClick={onClick}
      className={`glass-card p-6 text-center ${onClick ? 'cursor-pointer' : ''}`}
    >
      <div className="relative mx-auto mb-4 w-28 h-28">
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-neon-blue to-violet-500 opacity-50 blur-lg" />
        {photo ? (
          <img
            src={photo}
            alt={name}
            className="relative w-28 h-28 rounded-full object-cover border-2 border-neon-blue/40"
          />
        ) : (
          <div className="relative w-28 h-28 rounded-full bg-dark-700 border-2 border-white/10 flex items-center justify-center">
            <User className="h-12 w-12 text-gray-500" />
          </div>
        )}
      </div>
      <h3 className="font-semibold text-white text-lg mb-1">{name || '—'}</h3>
      {title && <div className="text-sm text-neon-blue font-medium mb-1">{title}</div>}
      {subtitle && <div className="text-xs text-gray-400 mb-3">{subtitle}</div>}
      {children}
    </motion.div>
  )
}