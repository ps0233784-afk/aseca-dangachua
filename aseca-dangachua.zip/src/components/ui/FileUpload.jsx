import { useState, useRef, useCallback } from 'react'
import { Upload, X, FileText, CheckCircle2 } from 'lucide-react'
import { uploadFile, validateFile } from '../../services/storageService'
import { deleteFile } from '../../services/storageService'

export default function FileUpload({
  folder = 'uploads',
  value = '',
  onChange,
  accept = 'image/*',
  maxSize = 10,
  label = 'Upload File',
  description = 'Drag & drop a file here, or click to browse',
  onUploadStart,
  onUploadComplete,
  onUploadError
}) {
  const [dragActive, setDragActive] = useState(false)
  const [progress, setProgress] = useState(0)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState(null)
  const inputRef = useRef(null)

  const isImage = (file) => file && file.type.startsWith('image/')
  const isPdf = (file) => file && file.type === 'application/pdf'

  const handleUpload = async (file) => {
    if (!file) return

    const validation = validateFile(file, accept.split(','))
    if (!validation.valid) {
      setError(validation.error)
      if (onUploadError) onUploadError(validation.error)
      return
    }

    setError(null)
    setUploading(true)
    if (onUploadStart) onUploadStart()

    try {
      const timestamp = Date.now()
      const safeName = file.name.replace(/[^a-zA-Z0-9.]/g, '_')
      const path = `${folder}/${timestamp}-${safeName}`
      const result = await uploadFile(path, file, (p) => setProgress(p))

      // Delete old file if replacing
      if (value && value.includes('/')) {
        const oldPath = value.match(/\/o\/(.*?)\?alt/)?.[1]
        if (oldPath) {
          try {
            await deleteFile(decodeURIComponent(oldPath))
          } catch (e) {
            // Old file delete failure is non-critical
          }
        }
      }

      onChange(result.url)
      if (onUploadComplete) onUploadComplete(result)
      setTimeout(() => setProgress(0), 1000)
    } catch (err) {
      setError('Upload failed. Please try again.')
      if (onUploadError) onUploadError(err)
    } finally {
      setUploading(false)
    }
  }

  const handleDrop = useCallback((e) => {
    e.preventDefault()
    setDragActive(false)
    const file = e.dataTransfer.files[0]
    if (file) handleUpload(file)
  }, [value, onChange])

  const handleChange = (e) => {
    const file = e.target.files[0]
    if (file) handleUpload(file)
  }

  const handleRemove = async () => {
    if (value && value.includes('firebasestorage')) {
      const oldPath = value.match(/\/o\/(.*?)\?alt/)?.[1]
      if (oldPath) {
        try {
          await deleteFile(decodeURIComponent(oldPath))
        } catch (e) {
          // non-critical
        }
      }
    }
    onChange('')
  }

  return (
    <div className="w-full">
      <label className="neon-label">{label}</label>

      {value ? (
        <div className="glass-card p-4 flex items-center gap-4">
          <div className="relative h-20 w-20 shrink-0 rounded-xl overflow-hidden bg-dark-700 flex items-center justify-center">
            {isImage({ type: value.split('?')[0] } ) ? (
              value.includes('firebasestorage') || value.startsWith('http') ? (
                <img src={value} alt="Uploaded" className="h-full w-full object-cover" />
              ) : (
                <div className="flex flex-col items-center text-gray-400">
                  <FileText className="h-8 w-8" />
                </div>
              )
            ) : (
              <FileText className="h-8 w-8 text-neon-blue" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm text-white font-medium truncate">
              {isPdf({ type: value.split('?')[0] }) ? 'PDF Document' : 'Uploaded File'}
            </div>
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="text-xs text-neon-blue hover:underline mt-1"
            >
              Replace File
            </button>
          </div>
          <button
            type="button"
            onClick={handleRemove}
            className="p-2 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
            title="Remove file"
          >
            <X className="h-5 w-5" />
          </button>
          <input
            ref={inputRef}
            type="file"
            accept={accept}
            onChange={handleChange}
            className="hidden"
            disabled={uploading}
          />
        </div>
      ) : (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragActive(true) }}
          onDragLeave={() => setDragActive(false)}
          onDrop={handleDrop}
          onClick={() => inputRef.current?.click()}
          className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-300 ${
            dragActive
              ? 'border-neon-blue bg-neon-blue/10 shadow-neon-blue'
              : 'border-white/15 hover:border-neon-blue/40 hover:bg-white/5'
          }`}
        >
          <input
            ref={inputRef}
            type="file"
            accept={accept}
            onChange={handleChange}
            className="hidden"
            disabled={uploading}
          />
          {uploading ? (
            <div>
              <div className="mx-auto mb-4 relative">
                <div className="h-16 w-16 flex items-center justify-center">
                  <Upload className="h-8 w-8 text-neon-blue animate-bounce" />
                </div>
                <div className="absolute -top-2 -right-2">
                  <CheckCircle2 className="h-5 w-5 text-neon-emerald" />
                </div>
              </div>
              <div className="mb-3">
                <div className="flex justify-between text-xs mb-2">
                  <span className="text-gray-400">Uploading...</span>
                  <span className="text-neon-blue font-semibold">{Math.round(progress)}%</span>
                </div>
                <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-neon-blue to-violet-500 transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            </div>
          ) : (
            <>
              <div className={`mx-auto mb-4 p-4 rounded-2xl inline-block ${dragActive ? 'bg-neon-blue/20' : 'bg-white/5'}`}>
                <Upload className={`h-8 w-8 ${dragActive ? 'text-neon-blue' : 'text-gray-400'}`} />
              </div>
              <p className="text-sm text-white font-medium mb-1">{description}</p>
              <p className="text-xs text-gray-500">
                Max file size: {maxSize}MB • {accept.split(',').join(' or ')}
              </p>
            </>
          )}
        </div>
      )}

      {error && (
        <p className="mt-2 text-sm text-red-400">{error}</p>
      )}
    </div>
  )
}