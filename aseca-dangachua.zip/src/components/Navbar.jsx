import { useState, useEffect } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, GraduationCap, LogIn, ChevronDown } from 'lucide-react'
import { useSettings } from '../contexts/SettingsContext'
import { useAuth } from '../contexts/AuthContext'

const navItems = [
  { label: 'Home', path: '/' },
  { label: 'About', path: '/about' },
  { label: 'Managing Body', path: '/managing-body' },
  { label: 'Schools', path: '/schools' },
  { label: 'Teachers', path: '/teachers' },
  { label: 'Students', path: '/students' },
  { label: 'Attendance', path: '/attendance' },
  { label: 'Examinations', path: '/examinations' },
  { label: 'Results', path: '/results' },
  { label: 'Library', path: '/library' },
  { label: 'News', path: '/news' },
  { label: 'Gallery', path: '/gallery' },
  { label: 'Culture', path: '/culture' },
  { label: 'Contact', path: '/contact' }
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [moreOpen, setMoreOpen] = useState(false)
  const { settings } = useSettings()
  const { isAdmin } = useAuth()
  const location = useLocation()
  const navigate = useNavigate()

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    setMobileOpen(false)
    setMoreOpen(false)
  }, [location.pathname])

  const primaryNav = navItems.slice(0, 7)
  const moreNav = navItems.slice(7)

  const handleAdminClick = () => {
    if (isAdmin) {
      navigate('/admin/dashboard')
    } else {
      navigate('/admin/login')
    }
  }

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-dark-900/90 backdrop-blur-xl shadow-lg border-b border-white/10' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            {settings.logo ? (
              <img src={settings.logo} alt="Logo" className="h-10 w-10 rounded-lg object-cover" />
            ) : (
              <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-neon-blue to-violet-500 flex items-center justify-center shadow-neon-blue">
                <GraduationCap className="h-6 w-6 text-white" />
              </div>
            )}
            <div className="hidden sm:block">
              <div className="font-display font-bold text-sm leading-tight neon-text">{settings.institutionName}</div>
              <div className="text-[10px] text-gray-400">{settings.tagline}</div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-1">
            {primaryNav.map(item => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                  location.pathname === item.path
                    ? 'text-neon-blue bg-neon-blue/10'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.label}
              </Link>
            ))}

            {/* More dropdown */}
            <div className="relative">
              <button
                onClick={() => setMoreOpen(!moreOpen)}
                className="flex items-center px-3 py-2 rounded-lg text-sm font-medium text-gray-300 hover:text-white hover:bg-white/5 transition-all"
              >
                More <ChevronDown className="h-4 w-4 ml-1" />
              </button>
              <AnimatePresence>
                {moreOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute right-0 mt-2 w-56 glass-strong p-2"
                  >
                    {moreNav.map(item => (
                      <Link
                        key={item.path}
                        to={item.path}
                        className="block px-4 py-2 rounded-lg text-sm text-gray-300 hover:text-neon-blue hover:bg-neon-blue/10 transition-all"
                      >
                        {item.label}
                      </Link>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <button
              onClick={handleAdminClick}
              className="ml-2 neon-btn flex items-center gap-2 !px-4 !py-2 text-sm"
            >
              <LogIn className="h-4 w-4" />
              {isAdmin ? 'Dashboard' : 'Admin Login'}
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden p-2 rounded-lg text-white hover:bg-white/10"
          >
            {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-dark-900/95 backdrop-blur-xl border-t border-white/10 overflow-hidden"
          >
            <div className="px-4 py-4 max-h-[calc(100vh-4rem)] overflow-y-auto">
              {navItems.map(item => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`block px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                    location.pathname === item.path
                      ? 'text-neon-blue bg-neon-blue/10'
                      : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </Link>
              ))}
              <button
                onClick={handleAdminClick}
                className="mt-2 w-full neon-btn flex items-center justify-center gap-2"
              >
                <LogIn className="h-4 w-4" />
                {isAdmin ? 'Dashboard' : 'Admin Login'}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  )
}