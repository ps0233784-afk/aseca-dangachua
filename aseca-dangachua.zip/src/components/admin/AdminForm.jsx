import { useState } from 'react'
import { Save, X } from 'lucide-react'
import { FileUpload, RichTextEditor } from '../ui'

export default function AdminForm({ fields, initialData = {}, onSave, onCancel, saving }) {
  const [form, setForm] = useState(initialData)

  const handleChange = (key, value) => {
    setForm(prev => ({ ...prev, [key]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    onSave(form)
  }

  const renderField = (field) => {
    const { key, label, type = 'text', required = false, placeholder = '', options = [], help = '' } = field
    const value = form[key] || ''

    switch (type) {
      case 'textarea':
        return (
          <div key={key}>
            <label className="neon-label">{label} {required && '*'}</label>
            <textarea
              value={value}
              onChange={(e) => handleChange(key, e.target.value)}
              placeholder={placeholder}
              rows={field.rows || 4}
              className="neon-input resize-none"
              required={required}
            />
            {help && <p className="text-xs text-gray-500 mt-1">{help}</p>}
          </div>
        )
      case 'richText':
        return (
          <div key={key}>
            <RichTextEditor
              value={value}
              onChange={(val) => handleChange(key, val)}
              label={label}
              placeholder={placeholder}
            />
            {help && <p className="text-xs text-gray-500 mt-1">{help}</p>}
          </div>
        )
      case 'select':
        return (
          <div key={key}>
            <label className="neon-label">{label} {required && '*'}</label>
            <select
              value={value}
              onChange={(e) => handleChange(key, e.target.value)}
              className="neon-select"
              required={required}
            >
              <option value="">Select...</option>
              {options.map(opt => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
            {help && <p className="text-xs text-gray-500 mt-1">{help}</p>}
          </div>
        )
      case 'file':
        return (
          <div key={key}>
            <FileUpload
              folder={field.folder || 'uploads'}
              value={value}
              onChange={(url) => handleChange(key, url)}
              label={label}
              description={field.description || 'Upload a file'}
              accept={field.accept || 'image/*'}
            />
            {help && <p className="text-xs text-gray-500 mt-1">{help}</p>}
          </div>
        )
      case 'date':
        return (
          <div key={key}>
            <label className="neon-label">{label} {required && '*'}</label>
            <input
              type="date"
              value={value}
              onChange={(e) => handleChange(key, e.target.value)}
              className="neon-input"
              required={required}
            />
            {help && <p className="text-xs text-gray-500 mt-1">{help}</p>}
          </div>
        )
      case 'number':
        return (
          <div key={key}>
            <label className="neon-label">{label} {required && '*'}</label>
            <input
              type="number"
              value={value}
              onChange={(e) => handleChange(key, e.target.value)}
              placeholder={placeholder}
              className="neon-input"
              required={required}
            />
            {help && <p className="text-xs text-gray-500 mt-1">{help}</p>}
          </div>
        )
      case 'toggle':
        return (
          <div key={key} className="flex items-center justify-between p-3 rounded-xl bg-white/5">
            <div>
              <div className="text-sm text-white font-medium">{label}</div>
              {help && <div className="text-xs text-gray-500">{help}</div>}
            </div>
            <label className="toggle-switch">
              <input
                type="checkbox"
                checked={!!form[key]}
                onChange={(e) => handleChange(key, e.target.checked)}
              />
              <span className="track" />
              <span className="thumb" />
            </label>
          </div>
        )
      default:
        return (
          <div key={key}>
            <label className="neon-label">{label} {required && '*'}</label>
            <input
              type={type}
              value={value}
              onChange={(e) => handleChange(key, e.target.value)}
              placeholder={placeholder}
              className="neon-input"
              required={required}
            />
            {help && <p className="text-xs text-gray-500 mt-1">{help}</p>}
          </div>
        )
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        {fields.map(field => renderField(field))}
      </div>
      <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
        <button
          type="button"
          onClick={onCancel}
          disabled={saving}
          className="px-4 py-2 rounded-xl border border-white/10 hover:bg-white/5 text-sm text-gray-300 transition-colors"
        >
          <X className="h-4 w-4 inline mr-1" /> Cancel
        </button>
        <button
          type="submit"
          disabled={saving}
          className="neon-btn flex items-center gap-2 text-sm !py-2 disabled:opacity-50"
        >
          <Save className="h-4 w-4" /> {saving ? 'Saving...' : 'Save'}
        </button>
      </div>
    </form>
  )
}