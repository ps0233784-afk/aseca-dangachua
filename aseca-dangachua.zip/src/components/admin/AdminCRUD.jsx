import { useState, useMemo } from 'react'
import { Plus, Pencil, Trash2, Eye, EyeOff, Search } from 'lucide-react'
import { useCollection } from '../../hooks/useCollection'
import { addDocument, updateDocument, deleteDocument } from '../../services/firestoreService'
import { Modal, ConfirmDialog, EmptyState, Loader, Pagination } from '../ui'
import toast from 'react-hot-toast'

const ITEMS_PER_PAGE = 10

export default function AdminCRUD({
  collection,
  title,
  description,
  fields,
  searchFields = [],
  renderCard,
  formComponent: FormComponent,
  defaultValues = {}
}) {
  const { data, loading, refetch } = useCollection(collection, [], true)
  const [search, setSearch] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)
  const [deleting, setDeleting] = useState(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [saving, setSaving] = useState(false)

  const filtered = useMemo(() => {
    if (!search) return data
    const q = search.toLowerCase()
    return data.filter(item => {
      return searchFields.some(field => {
        const val = item[field]
        return val && String(val).toLowerCase().includes(q)
      })
    })
  }, [data, search, searchFields])

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE)
  const paginated = filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE)

  const handleSave = async (formData) => {
    setSaving(true)
    try {
      if (editing) {
        await updateDocument(collection, editing.id, formData)
        toast.success('Updated successfully!')
      } else {
        await addDocument(collection, { ...formData, published: true })
        toast.success('Added successfully!')
      }
      setShowForm(false)
      setEditing(null)
      refetch()
    } catch (error) {
      console.error('Error saving:', error)
      toast.error('Failed to save. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!deleting) return
    try {
      await deleteDocument(collection, deleting.id)
      toast.success('Deleted successfully!')
      setDeleting(null)
      refetch()
    } catch (error) {
      console.error('Error deleting:', error)
      toast.error('Failed to delete.')
    }
  }

  const handleTogglePublish = async (item) => {
    try {
      await updateDocument(collection, item.id, { published: !item.published })
      toast.success(item.published ? 'Unpublished' : 'Published')
      refetch()
    } catch (error) {
      console.error('Error toggling publish:', error)
      toast.error('Failed to update status.')
    }
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold neon-text mb-1">{title}</h1>
          <p className="text-gray-400 text-sm">{description}</p>
        </div>
        <button
          onClick={() => { setEditing(null); setShowForm(true) }}
          className="neon-btn flex items-center gap-2 text-sm !py-2.5"
        >
          <Plus className="h-4 w-4" /> Add New
        </button>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
        <input
          type="text"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setCurrentPage(1) }}
          placeholder={`Search ${title.toLowerCase()}...`}
          className="neon-input !pl-10"
        />
      </div>

      {loading ? <Loader /> : paginated.length === 0 ? (
        <EmptyState title={`No ${title.toLowerCase()} found`} description="Click 'Add New' to create your first item." />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {paginated.map((item, i) => (
            <div key={item.id} className="glass-card p-4">
              {renderCard ? renderCard(item) : (
                <div className="text-white font-medium mb-2">{item.name || item.title || 'Item'}</div>
              )}
              <div className="flex items-center gap-2 mt-4 pt-3 border-t border-white/10">
                <button
                  onClick={() => { setEditing(item); setShowForm(true) }}
                  className="p-2 rounded-lg bg-white/5 hover:bg-neon-blue/20 text-gray-400 hover:text-neon-blue transition-colors"
                  title="Edit"
                >
                  <Pencil className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleTogglePublish(item)}
                  className="p-2 rounded-lg bg-white/5 hover:bg-neon-gold/20 text-gray-400 hover:text-neon-gold transition-colors"
                  title={item.published ? 'Unpublish' : 'Publish'}
                >
                  {item.published ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </button>
                <button
                  onClick={() => setDeleting(item)}
                  className="p-2 rounded-lg bg-white/5 hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition-colors"
                  title="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
                <span className={`ml-auto pill ${item.published ? 'pill-green' : 'pill-gold'}`}>
                  {item.published ? 'Published' : 'Draft'}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />

      <Modal
        open={showForm}
        onClose={() => { setShowForm(false); setEditing(null) }}
        title={editing ? `Edit ${title.slice(0, -1)}` : `Add New ${title.slice(0, -1)}`}
        size="xl"
      >
        {FormComponent && (
          <FormComponent
            initialData={editing || defaultValues}
            onSave={handleSave}
            onCancel={() => { setShowForm(false); setEditing(null) }}
            saving={saving}
          />
        )}
      </Modal>

      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        onConfirm={handleDelete}
        title="Delete Item"
        message={`Are you sure you want to delete "${deleting?.name || deleting?.title || 'this item'}"? This action cannot be undone.`}
      />
    </div>
  )
}