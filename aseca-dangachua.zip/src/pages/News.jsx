import { useState, useMemo } from 'react'
import { PageHeader, SearchBar, Loader, EmptyState, Modal, Pagination } from '../components/ui'
import { Newspaper, Calendar, Pin, Clock } from 'lucide-react'
import { useCollection } from '../hooks/useCollection'
import { where, orderBy } from 'firebase/firestore'
import { formatDate } from '../utils/helpers'

const ITEMS_PER_PAGE = 9

export default function News() {
  const { data: news, loading } = useCollection('news', [where('published', '==', true), orderBy('createdAt', 'desc')])
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('all')
  const [selected, setSelected] = useState(null)
  const [currentPage, setCurrentPage] = useState(1)

  const categories = useMemo(() => {
    const set = new Set(news.map(n => n.category).filter(Boolean))
    return ['all', ...set]
  }, [news])

  const filtered = useMemo(() => {
    return news.filter(item => {
      const q = search.toLowerCase()
      const matchesSearch = !q ||
        item.title?.toLowerCase().includes(q) ||
        item.content?.toLowerCase().includes(q)
      const matchesCategory = category === 'all' || item.category === category
      return matchesSearch && matchesCategory
    })
  }, [news, search, category])

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE)
  const paginated = filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE)

  return (
    <div>
      <PageHeader
        icon={Newspaper}
        title="News & Events"
        subtitle="Stay updated with the latest happenings at our institution"
      />

      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-4 mb-8">
            <SearchBar
              value={search}
              onChange={setSearch}
              placeholder="Search news..."
            />
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="neon-select">
              <option value="all">All Categories</option>
              {categories.filter(c => c !== 'all').map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          {loading ? <Loader /> : paginated.length === 0 ? (
            <EmptyState title="No news found" description="News and events will appear here." />
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {paginated.map((item, i) => (
                <div
                  key={item.id}
                  onClick={() => setSelected(item)}
                  className="glass-card overflow-hidden card-hover cursor-pointer"
                >
                  {item.thumbnail && (
                    <img src={item.thumbnail} alt={item.title} className="h-48 w-full object-cover" />
                  )}
                  <div className="p-5">
                    <div className="flex items-center gap-2 mb-2">
                      {item.pinned && <Pin className="h-4 w-4 text-neon-gold" />}
                      <span className="pill pill-blue">{item.category || 'News'}</span>
                      {item.date && (
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          <Calendar className="h-3 w-3" /> {formatDate(item.date)}
                        </span>
                      )}
                    </div>
                    <h3 className="font-semibold text-white text-lg mb-2 line-clamp-2">{item.title}</h3>
                    <div className="text-sm text-gray-400 line-clamp-3" dangerouslySetInnerHTML={{ __html: item.content || '' }} />
                  </div>
                </div>
              ))}
            </div>
          )}

          <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
        </div>
      </section>

      <Modal open={!!selected} onClose={() => setSelected(null)} title={selected?.title || 'News'} size="xl">
        {selected && (
          <div>
            {selected.thumbnail && (
              <img src={selected.thumbnail} alt={selected.title} className="w-full h-64 object-cover rounded-xl mb-6" />
            )}
            <div className="flex items-center gap-3 mb-4">
              <span className="pill pill-blue">{selected.category || 'News'}</span>
              {selected.date && (
                <span className="text-sm text-gray-400 flex items-center gap-1">
                  <Calendar className="h-4 w-4" /> {formatDate(selected.date)}
                </span>
              )}
              {selected.pinned && <Pin className="h-4 w-4 text-neon-gold" />}
            </div>
            <div className="text-gray-300 leading-relaxed space-y-4" dangerouslySetInnerHTML={{ __html: selected.content || '' }} />
          </div>
        )}
      </Modal>
    </div>
  )
}