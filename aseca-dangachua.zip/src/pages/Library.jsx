import { useState, useMemo } from 'react'
import { PageHeader, SearchBar, Loader, EmptyState, Pagination } from '../components/ui'
import { BookOpen, FileText, Download, Eye, GraduationCap, BookMarked } from 'lucide-react'
import { useCollection } from '../hooks/useCollection'
import { where } from 'firebase/firestore'

const ITEMS_PER_PAGE = 12

export default function Library() {
  const { data: resources, loading } = useCollection('library', [where('published', '==', true)])
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('all')
  const [classFilter, setClassFilter] = useState('all')
  const [currentPage, setCurrentPage] = useState(1)

  const categories = useMemo(() => {
    const set = new Set(resources.map(r => r.category).filter(Boolean))
    return ['all', ...set]
  }, [resources])

  const classes = useMemo(() => {
    const set = new Set(resources.map(r => r.class).filter(Boolean))
    return ['all', ...set]
  }, [resources])

  const filtered = useMemo(() => {
    return resources.filter(resource => {
      const q = search.toLowerCase()
      const matchesSearch = !q ||
        resource.title?.toLowerCase().includes(q) ||
        resource.author?.toLowerCase().includes(q) ||
        resource.description?.toLowerCase().includes(q)
      const matchesCategory = category === 'all' || resource.category === category
      const matchesClass = classFilter === 'all' || resource.class === classFilter
      return matchesSearch && matchesCategory && matchesClass
    })
  }, [resources, search, category, classFilter])

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE)
  const paginated = filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE)

  const getIcon = (cat) => {
    if (cat === 'Book') return BookOpen
    if (cat === 'eBook') return BookMarked
    if (cat === 'Question Paper') return FileText
    return GraduationCap
  }

  return (
    <div>
      <PageHeader
        icon={BookOpen}
        title="Digital Library"
        subtitle="Books, study materials, question papers, and more"
      />

      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-4 mb-8">
            <SearchBar
              value={search}
              onChange={setSearch}
              placeholder="Search resources..."
              className="md:col-span-1"
            />
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="neon-select">
              <option value="all">All Categories</option>
              {categories.filter(c => c !== 'all').map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={classFilter} onChange={(e) => setClassFilter(e.target.value)} className="neon-select">
              <option value="all">All Classes</option>
              {classes.filter(c => c !== 'all').map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          {loading ? <Loader /> : paginated.length === 0 ? (
            <EmptyState title="No resources found" description="Try adjusting your search or filters." />
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {paginated.map((resource, i) => {
                const Icon = getIcon(resource.category)
                return (
                  <div key={resource.id} className="glass-card p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="p-3 rounded-xl bg-neon-blue/10 text-neon-blue">
                        <Icon className="h-6 w-6" />
                      </div>
                      <span className="pill pill-blue">{resource.category}</span>
                    </div>
                    <h3 className="font-semibold text-white text-lg mb-1">{resource.title}</h3>
                    {resource.author && <div className="text-sm text-gray-400 mb-2">By {resource.author}</div>}
                    {resource.description && (
                      <p className="text-sm text-gray-400 mb-4 line-clamp-2">{resource.description}</p>
                    )}
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">{resource.class || 'All Classes'}</span>
                      <div className="flex gap-2">
                        {resource.fileUrl && (
                          <a
                            href={resource.fileUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 rounded-lg bg-white/5 hover:bg-neon-blue/20 text-gray-400 hover:text-neon-blue transition-colors"
                            title="Preview"
                          >
                            <Eye className="h-4 w-4" />
                          </a>
                        )}
                        {resource.fileUrl && (
                          <a
                            href={resource.fileUrl}
                            download
                            className="p-2 rounded-lg bg-white/5 hover:bg-neon-emerald/20 text-gray-400 hover:text-neon-emerald transition-colors"
                            title="Download"
                          >
                            <Download className="h-4 w-4" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}

          <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
        </div>
      </section>
    </div>
  )
}