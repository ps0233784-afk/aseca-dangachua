import { useState } from 'react'
import { PageHeader } from '../components/ui'
import { Mail, Phone, MapPin, Send, MessageSquare, User, Clock } from 'lucide-react'
import { useSettings } from '../contexts/SettingsContext'
import { addDocument } from '../services/firestoreService'
import toast from 'react-hot-toast'

export default function Contact() {
  const { settings } = useSettings()
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' })
  const [sending, setSending] = useState(false)

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.name || !form.email || !form.message) {
      toast.error('Please fill in all required fields.')
      return
    }

    setSending(true)
    try {
      await addDocument('contactMessages', {
        ...form,
        status: 'new',
        createdAt: new Date().toISOString()
      })
      toast.success('Message sent successfully! We will get back to you soon.')
      setForm({ name: '', email: '', subject: '', message: '' })
    } catch (error) {
      console.error('Error sending message:', error)
      toast.error('Failed to send message. Please try again.')
    } finally {
      setSending(false)
    }
  }

  const contactInfo = [
    { icon: MapPin, label: 'Address', value: settings.address, color: 'text-neon-blue' },
    { icon: Phone, label: 'Phone', value: settings.contactPhone, color: 'text-neon-emerald' },
    { icon: Mail, label: 'Email', value: settings.contactEmail, color: 'text-neon-gold' },
    { icon: Clock, label: 'Office Hours', value: 'Mon - Sat: 9:00 AM - 5:00 PM', color: 'text-violet-400' }
  ]

  return (
    <div>
      <PageHeader
        icon={MessageSquare}
        title="Contact Us"
        subtitle="We'd love to hear from you. Send us a message!"
      />

      <section className="py-12 px-4">
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-8">
          {/* Contact info */}
          <div>
            <h2 className="section-title neon-text mb-6">Get in Touch</h2>
            <div className="space-y-4 mb-8">
              {contactInfo.map((item, i) => (
                <div key={i} className="glass-card p-4 flex items-start gap-4">
                  <div className={`p-3 rounded-xl bg-white/5 ${item.color}`}>
                    <item.icon className="h-6 w-6" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">{item.label}</div>
                    <div className="text-white font-medium">{item.value}</div>
                  </div>
                </div>
              ))}
            </div>

            {settings.mapEmbed && (
              <div className="glass-card overflow-hidden">
                <iframe
                  src={settings.mapEmbed}
                  title="Location Map"
                  className="w-full h-64"
                  loading="lazy"
                  allowFullScreen
                />
              </div>
            )}
          </div>

          {/* Contact form */}
          <div className="glass-strong p-6 md:p-8">
            <h2 className="section-title neon-text mb-6">Send a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="neon-label">Your Name *</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <input
                    type="text"
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    placeholder="Enter your full name"
                    className="neon-input !pl-10"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="neon-label">Email Address *</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <input
                    type="email"
                    name="email"
                    value={form.email}
                    onChange={handleChange}
                    placeholder="Enter your email"
                    className="neon-input !pl-10"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="neon-label">Subject</label>
                <input
                  type="text"
                  name="subject"
                  value={form.subject}
                  onChange={handleChange}
                  placeholder="What is this about?"
                  className="neon-input"
                />
              </div>

              <div>
                <label className="neon-label">Message *</label>
                <textarea
                  name="message"
                  value={form.message}
                  onChange={handleChange}
                  placeholder="Write your message here..."
                  rows="5"
                  className="neon-input resize-none"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={sending}
                className="neon-btn w-full flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Send className="h-4 w-4" />
                {sending ? 'Sending...' : 'Send Message'}
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  )
}