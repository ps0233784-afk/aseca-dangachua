import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { PageHeader, SearchBar, Loader, EmptyState, Pagination } from '../components/ui'
import { School, Users, GraduationCap, MapPin, ChevronRight } from 'lucide-react'
import { useCollection } from '../hooks/useCollection'
import { where } from 'firebase/firestore'

const ITEMS_PER_PAGE = 9

export default function Schools() {
  const navigate = useNavigate()
  const { data: schools, loading } = useCollection('schools', [where('published', '==', true)])
  const [search, setSearch] = useState('')
  const [sortBy, setSortBy] = useState('name')
  const [currentPage, setCurrentPage] = useState(1)

  const filtered = useMemo(() => {
    let result = schools.filter(school => {
      const q = search.toLowerCase()
      return (
        !q ||
        school.name?.toLowerCase().includes(q) ||
        school.code?.toLowerCase().includes(q) ||
        school.principal?.toLowerCase().includes(q) ||
        school.address?.toLowerCase().includes(q)
      )
    })

    result.sort((a, b) => {
      if (sortBy === 'name') return (a.name || '').localeCompare(b.name || '')
      if (sortBy === 'teachers') return (b.teacherCount || 0) - (a.teacherCount || 0)
      if (sortBy === 'students') return (b.studentCount || 0) - (a.studentCount || 0)
      return 0
    })

    return result
  }, [schools, search, sortBy])

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE)
  const paginated = filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE)

  return (
    <div>
      <PageHeader
        icon={School}
        title="Our Schools"
        subtitle="Explore the schools under BRANCH ASECA DANGACHUA"
      />

      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <SearchBar
              value={search}
              onChange={setSearch}
              placeholder="Search school name, code, principal..."
              className="flex-1"
            />
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="neon-select md:w-48">
              <option value="name">Sort: Name</option>
              <option value="teachers">Sort: Teachers</option>
              <option value="students">Sort: Students</option>
            </select>
          </div>

          {loading ? <Loader /> : paginated.length === 0 ? (
            <EmptyState title="No schools found" description="Try adjusting your search." />
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {paginated.map((school) => (
                <div
                  key={school.id}
                  onClick={() => navigate(`/schools/${school.id}`)}
                  className="glass-card overflow-hidden card-hover cursor-pointer"
                >
                  <div className="h-48 bg-gradient-to-br from-neon-blue/20 to-violet-500/20 relative">
                    {school.photo ? (
                      <img src={school.photo} alt={school.name} className="h-full w-full object-cover" />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center">
                        <School className="h-16 w-16 text-white/30" />
                      </div>
                    )}
                    <div className="absolute top-3 left-3">
                      <span className="pill pill-blue">{school.code}</span>
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="font-semibold text-white text-lg mb-2">{school.name}</h3>
                    <div className="space-y-1.5 text-sm text-gray-400 mb-4">
                      {school.address && (
                        <div className="flex items-center gap-2"><MapPin className="h-4 w-4 text-neon-blue shrink-0" /> {school.address}</div>
                      )}
                      {school.principal && (
                        <div className="flex items-center gap-2"><GraduationCap className="h-4 w-4 text-neon-emerald shrink-0" /> {school.principal}</div>
                      )}
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-neon-gold shrink-0" />
                        {school.teacherCount || 0} Teachers • {school.studentCount || 0} Students
                      </div>
                    </div>
                    <button className="w-full neon-btn-secondary flex items-center justify-center gap-2 text-sm !py-2">
                      View Details <ChevronRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
        </div>
      </section>
    </div>
  )
}