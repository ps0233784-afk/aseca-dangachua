import { useState, useMemo } from 'react'
import { PageHeader, SearchBar, Loader, EmptyState, Modal, Pagination } from '../components/ui'
import { UserSquare, School, Users, Phone, MapPin, Droplet, Calendar, Printer, Download } from 'lucide-react'
import { useCollection } from '../hooks/useCollection'
import { formatDate, calculateAge } from '../utils/helpers'

const ITEMS_PER_PAGE = 12

export default function Students() {
  const { data: students, loading } = useCollection('students')
  const [search, setSearch] = useState('')
  const [schoolFilter, setSchoolFilter] = useState('all')
  const [classFilter, setClassFilter] = useState('all')
  const [selected, setSelected] = useState(null)
  const [currentPage, setCurrentPage] = useState(1)

  const schools = useMemo(() => {
    const set = new Set(students.map(s => s.school).filter(Boolean))
    return ['all', ...set]
  }, [students])

  const classes = useMemo(() => {
    const set = new Set(students.map(s => s.class).filter(Boolean))
    return ['all', ...set]
  }, [students])

  const filtered = useMemo(() => {
    return students.filter(student => {
      const q = search.toLowerCase()
      const matchesSearch = !q ||
        student.name?.toLowerCase().includes(q) ||
        student.studentId?.toLowerCase().includes(q) ||
        student.admissionNumber?.toLowerCase().includes(q) ||
        student.fatherName?.toLowerCase().includes(q)
      const matchesSchool = schoolFilter === 'all' || student.school === schoolFilter
      const matchesClass = classFilter === 'all' || student.class === classFilter
      return matchesSearch && matchesSchool && matchesClass
    })
  }, [students, search, schoolFilter, classFilter])

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE)
  const paginated = filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE)

  const handlePrint = () => {
    window.print()
  }

  const handleExport = () => {
    const csv = [
      ['Student ID', 'Name', 'Father', 'Mother', 'Class', 'Section', 'School', 'Contact'],
      ...filtered.map(s => [s.studentId, s.name, s.fatherName, s.motherName, s.class, s.section, s.school, s.contact])
    ].map(row => row.join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'students.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div>
      <PageHeader
        icon={UserSquare}
        title="Student Portal"
        subtitle="Find information about our students"
      />

      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-4 mb-8">
            <SearchBar
              value={search}
              onChange={setSearch}
              placeholder="Search by name, ID, admission no..."
              className="md:col-span-2"
            />
            <select value={schoolFilter} onChange={(e) => setSchoolFilter(e.target.value)} className="neon-select">
              <option value="all">All Schools</option>
              {schools.filter(s => s !== 'all').map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select value={classFilter} onChange={(e) => setClassFilter(e.target.value)} className="neon-select">
              <option value="all">All Classes</option>
              {classes.filter(c => c !== 'all').map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div className="flex gap-3 mb-6 no-print">
            <button onClick={handlePrint} className="neon-btn-secondary flex items-center gap-2 text-sm !py-2">
              <Printer className="h-4 w-4" /> Print
            </button>
            <button onClick={handleExport} className="neon-btn-secondary flex items-center gap-2 text-sm !py-2">
              <Download className="h-4 w-4" /> Export CSV
            </button>
          </div>

          {loading ? <Loader /> : paginated.length === 0 ? (
            <EmptyState title="No students found" description="Try adjusting your search or filters." />
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {paginated.map((student, i) => (
                <div
                  key={student.id}
                  onClick={() => setSelected(student)}
                  className="glass-card p-5 card-hover cursor-pointer"
                >
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 rounded-full overflow-hidden bg-dark-700 flex items-center justify-center shrink-0">
                      {student.photo ? (
                        <img src={student.photo} alt={student.name} className="h-full w-full object-cover" />
                      ) : (
                        <UserSquare className="h-8 w-8 text-gray-500" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-white truncate">{student.name}</h3>
                      <div className="text-xs text-neon-blue">{student.studentId}</div>
                      <div className="text-xs text-gray-400">{student.class} {student.section}</div>
                    </div>
                  </div>
                  <div className="space-y-1.5 text-xs text-gray-400">
                    {student.school && (
                      <div className="flex items-center gap-2"><School className="h-3 w-3 text-neon-blue" /> {student.school}</div>
                    )}
                    {student.fatherName && (
                      <div className="flex items-center gap-2"><Users className="h-3 w-3 text-neon-emerald" /> {student.fatherName}</div>
                    )}
                    {student.contact && (
                      <div className="flex items-center gap-2"><Phone className="h-3 w-3 text-neon-gold" /> {student.contact}</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
        </div>
      </section>

      <Modal open={!!selected} onClose={() => setSelected(null)} title="Student Profile" size="md">
        {selected && (
          <div>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-24 h-24 rounded-full overflow-hidden bg-dark-700 flex items-center justify-center shrink-0">
                {selected.photo ? (
                  <img src={selected.photo} alt={selected.name} className="h-full w-full object-cover" />
                ) : (
                  <UserSquare className="h-12 w-12 text-gray-500" />
                )}
              </div>
              <div>
                <h3 className="font-semibold text-white text-xl">{selected.name}</h3>
                <div className="text-neon-blue text-sm">{selected.studentId}</div>
                <div className="text-gray-400 text-sm">{selected.class} {selected.section} • Roll: {selected.rollNumber}</div>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { label: 'Admission No', value: selected.admissionNumber, icon: Calendar },
                { label: 'Father\'s Name', value: selected.fatherName, icon: Users },
                { label: 'Mother\'s Name', value: selected.motherName, icon: Users },
                { label: 'Gender', value: selected.gender, icon: UserSquare },
                { label: 'Date of Birth', value: formatDate(selected.dob), icon: Calendar },
                { label: 'Age', value: calculateAge(selected.dob), icon: Calendar },
                { label: 'School', value: selected.school, icon: School },
                { label: 'Blood Group', value: selected.bloodGroup, icon: Droplet },
                { label: 'Address', value: selected.address, icon: MapPin },
                { label: 'Contact', value: selected.contact, icon: Phone },
                { label: 'Admission Date', value: formatDate(selected.admissionDate), icon: Calendar }
              ].filter(item => item.value).map((item, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-white/5">
                  <item.icon className="h-4 w-4 text-neon-blue shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs text-gray-500">{item.label}</div>
                    <div className="text-sm text-white">{item.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}