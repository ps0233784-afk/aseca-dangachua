import AdminCRUD from '../../components/admin/AdminCRUD'
import AdminForm from '../../components/admin/AdminForm'
import { BookOpen } from 'lucide-react'

const fields = [
  { key: 'title', label: 'Title', type: 'text', required: true, placeholder: 'Enter resource title' },
  { key: 'category', label: 'Category', type: 'select', options: ['Book', 'eBook', 'Notes', 'Question Paper', 'Syllabus', 'Study Material', 'Circular', 'Annual Report'] },
  { key: 'author', label: 'Author', type: 'text', placeholder: 'Author name' },
  { key: 'class', label: 'Class', type: 'text', placeholder: 'e.g. Class 5' },
  { key: 'subject', label: 'Subject', type: 'text', placeholder: 'e.g. Mathematics' },
  { key: 'description', label: 'Description', type: 'textarea', rows: 3, placeholder: 'Brief description' },
  { key: 'fileUrl', label: 'File', type: 'file', folder: 'library', accept: 'application/pdf,image/*', description: 'Upload PDF or image file' }
]

export default function AdminLibrary() {
  return (
    <AdminCRUD
      collection="library"
      title="Library"
      description="Manage library resources and study materials"
      searchFields={['title', 'author', 'category']}
      defaultValues={{ published: true }}
      renderCard={(resource) => (
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-neon-blue/10 text-neon-blue">
            <BookOpen className="h-5 w-5" />
          </div>
          <div>
            <div className="text-white font-medium">{resource.title}</div>
            <div className="text-xs text-gray-500">{resource.category} • {resource.class || 'All Classes'}</div>
            {resource.author && <div className="text-xs text-gray-500">By {resource.author}</div>}
          </div>
        </div>
      )}
      formComponent={(props) => <AdminForm fields={fields} {...props} />}
    />
  )
}