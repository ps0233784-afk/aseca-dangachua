import { useState, useMemo } from 'react'
import { useCollection } from '../../hooks/useCollection'
import { addDocument, updateDocument } from '../../services/firestoreService'
import { Loader, EmptyState, SearchBar } from '../../components/ui'
import { CheckCircle2, XCircle, Clock, UserX, Calendar } from 'lucide-react'
import { formatDate } from '../../utils/helpers'
import toast from 'react-hot-toast'

const STATUSES = [
  { value: 'present', label: 'PRESENT', icon: CheckCircle2, color: 'bg-neon-emerald/20 text-neon-emerald border-neon-emerald/40 hover:bg-neon-emerald/30' },
  { value: 'absent', label: 'ABSENT', icon: XCircle, color: 'bg-red-500/20 text-red-400 border-red-500/40 hover:bg-red-500/30' },
  { value: 'leave', label: 'LEAVE', icon: Clock, color: 'bg-neon-gold/20 text-neon-gold border-neon-gold/40 hover:bg-neon-gold/30' },
  { value: 'halfDay', label: 'HALF DAY', icon: UserX, color: 'bg-violet-500/20 text-violet-400 border-violet-500/40 hover:bg-violet-500/30' }
]

export default function AdminAttendance() {
  const { data: teachers, loading: teachersLoading } = useCollection('teachers')
  const { data: attendance, loading: attLoading, refetch } = useCollection('teacherAttendance', [], true)
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().split('T')[0])
  const [search, setSearch] = useState('')
  const [savingId, setSavingId] = useState(null)

  const todaysRecords = useMemo(() => {
    return attendance.filter(record => {
      const d = record.date ? new Date(record.date.seconds ? record.date.seconds * 1000 : record.date) : null
      return d && d.toISOString().split('T')[0] === selectedDate
    })
  }, [attendance, selectedDate])

  const getStatusForTeacher = (teacherId) => {
    const record = todaysRecords.find(r => r.teacherId === teacherId)
    return record?.status || null
  }

  const filteredTeachers = useMemo(() => {
    if (!search) return teachers
    const q = search.toLowerCase()
    return teachers.filter(t => t.name?.toLowerCase().includes(q))
  }, [teachers, search])

  const handleMark = async (teacher, status) => {
    setSavingId(teacher.id)
    try {
      const existing = todaysRecords.find(r => r.teacherId === teacher.id)
      const recordData = {
        teacherId: teacher.id,
        teacherName: teacher.name,
        date: new Date(`${selectedDate}T00:00:00`),
        status,
        remarks: ''
      }

      if (existing) {
        await updateDocument('teacherAttendance', existing.id, { status })
      } else {
        await addDocument('teacherAttendance', recordData)
      }
      toast.success(`${teacher.name}: ${status.charAt(0).toUpperCase() + status.slice(1)}`)
      refetch()
    } catch (error) {
      console.error('Error marking attendance:', error)
      toast.error('Failed to mark attendance.')
    } finally {
      setSavingId(null)
    }
  }

  const stats = useMemo(() => {
    const total = todaysRecords.length
    const present = todaysRecords.filter(r => r.status === 'present').length
    const absent = todaysRecords.filter(r => r.status === 'absent').length
    const leave = todaysRecords.filter(r => r.status === 'leave').length
    const halfDay = todaysRecords.filter(r => r.status === 'halfDay').length
    return { total, present, absent, leave, halfDay }
  }, [todaysRecords])

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold neon-text mb-2">Teacher Attendance</h1>
        <p className="text-gray-400">Mark daily attendance with one tap</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex items-center gap-2 glass-card px-4 py-2">
          <Calendar className="h-5 w-5 text-neon-blue" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="bg-transparent text-white focus:outline-none"
          />
        </div>
        <SearchBar value={search} onChange={setSearch} placeholder="Search teachers..." className="flex-1" />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
        <div className="glass-card p-4 text-center">
          <div className="text-2xl font-bold text-white">{stats.total}</div>
          <div className="text-xs text-gray-400">Marked</div>
        </div>
        <div className="glass-card p-4 text-center">
          <div className="text-2xl font-bold text-neon-emerald">{stats.present}</div>
          <div className="text-xs text-gray-400">Present</div>
        </div>
        <div className="glass-card p-4 text-center">
          <div className="text-2xl font-bold text-red-400">{stats.absent}</div>
          <div className="text-xs text-gray-400">Absent</div>
        </div>
        <div className="glass-card p-4 text-center">
          <div className="text-2xl font-bold text-neon-gold">{stats.leave}</div>
          <div className="text-xs text-gray-400">Leave</div>
        </div>
        <div className="glass-card p-4 text-center">
          <div className="text-2xl font-bold text-violet-400">{stats.halfDay}</div>
          <div className="text-xs text-gray-400">Half Day</div>
        </div>
      </div>

      {teachersLoading || attLoading ? <Loader /> : filteredTeachers.length === 0 ? (
        <EmptyState title="No teachers found" description="Add teachers to mark attendance." />
      ) : (
        <div className="space-y-4">
          {filteredTeachers.map(teacher => {
            const currentStatus = getStatusForTeacher(teacher.id)
            return (
              <div key={teacher.id} className="glass-card p-4 md:p-6">
                <div className="flex flex-col md:flex-row md:items-center gap-4">
                  <div className="flex items-center gap-3 md:w-64 shrink-0">
                    {teacher.photo ? (
                      <img src={teacher.photo} alt={teacher.name} className="w-12 h-12 rounded-full object-cover" />
                    ) : (
                      <div className="w-12 h-12 rounded-full bg-dark-700 flex items-center justify-center text-white font-bold">
                        {teacher.name?.[0] || 'T'}
                      </div>
                    )}
                    <div>
                      <div className="text-white font-medium">{teacher.name}</div>
                      <div className="text-xs text-gray-500">{teacher.designation}</div>
                    </div>
                  </div>

                  <div className="flex-1 grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {STATUSES.map(status => {
                      const isActive = currentStatus === status.value
                      return (
                        <button
                          key={status.value}
                          onClick={() => handleMark(teacher, status.value)}
                          disabled={savingId === teacher.id}
                          className={`flex items-center justify-center gap-2 px-3 py-3 rounded-xl border text-sm font-semibold transition-all disabled:opacity-50 ${
                            isActive ? status.color + ' shadow-lg' : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10'
                          }`}
                        >
                          <status.icon className="h-4 w-4" />
                          {status.label}
                        </button>
                      )
                    })}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}