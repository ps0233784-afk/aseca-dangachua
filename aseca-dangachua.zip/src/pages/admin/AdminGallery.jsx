import { useState } from 'react'
import { useCollection } from '../../hooks/useCollection'
import { addDocument, updateDocument, deleteDocument } from '../../services/firestoreService'
import { FileUpload, Modal, ConfirmDialog, Loader, EmptyState } from '../../components/ui'
import { Plus, Images, Trash2, X } from 'lucide-react'
import toast from 'react-hot-toast'

export default function AdminGallery() {
  const { data: albums, loading, refetch } = useCollection('galleryAlbums', [], true)
  const { data: allImages, refetch: refetchImages } = useCollection('galleryImages', [], true)
  const [showAlbumForm, setShowAlbumForm] = useState(false)
  const [editingAlbum, setEditingAlbum] = useState(null)
  const [selectedAlbum, setSelectedAlbum] = useState(null)
  const [deleting, setDeleting] = useState(null)
  const [albumForm, setAlbumForm] = useState({ title: '', description: '', coverImage: '' })
  const [saving, setSaving] = useState(false)

  const albumImages = selectedAlbum ? allImages.filter(img => img.albumId === selectedAlbum.id) : []

  const handleSaveAlbum = async () => {
    if (!albumForm.title) {
      toast.error('Please enter an album title.')
      return
    }
    setSaving(true)
    try {
      if (editingAlbum) {
        await updateDocument('galleryAlbums', editingAlbum.id, albumForm)
        toast.success('Album updated successfully!')
      } else {
        await addDocument('galleryAlbums', { ...albumForm, published: true })
        toast.success('Album created successfully!')
      }
      setShowAlbumForm(false)
      setEditingAlbum(null)
      setAlbumForm({ title: '', description: '', coverImage: '' })
      refetch()
    } catch (error) {
      console.error('Error saving album:', error)
      toast.error('Failed to save album.')
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteAlbum = async () => {
    if (!deleting) return
    try {
      await deleteDocument('galleryAlbums', deleting.id)
      toast.success('Album deleted successfully!')
      setDeleting(null)
      refetch()
    } catch (error) {
      console.error('Error deleting album:', error)
      toast.error('Failed to delete album.')
    }
  }

  const handleAddImage = async (url) => {
    if (!selectedAlbum) return
    try {
      await addDocument('galleryImages', {
        albumId: selectedAlbum.id,
        url,
        caption: '',
        createdAt: new Date().toISOString()
      })
      toast.success('Image added successfully!')
      refetchImages()
    } catch (error) {
      console.error('Error adding image:', error)
      toast.error('Failed to add image.')
    }
  }

  const handleDeleteImage = async (image) => {
    try {
      await deleteDocument('galleryImages', image.id)
      toast.success('Image deleted successfully!')
      refetchImages()
    } catch (error) {
      console.error('Error deleting image:', error)
      toast.error('Failed to delete image.')
    }
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold neon-text mb-1">Photo Gallery</h1>
          <p className="text-gray-400 text-sm">Manage photo albums and images</p>
        </div>
        <button
          onClick={() => { setEditingAlbum(null); setAlbumForm({ title: '', description: '', coverImage: '' }); setShowAlbumForm(true) }}
          className="neon-btn flex items-center gap-2 text-sm !py-2.5"
        >
          <Plus className="h-4 w-4" /> New Album
        </button>
      </div>

      {loading ? <Loader /> : albums.length === 0 ? (
        <EmptyState title="No albums yet" description="Create your first photo album." />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {albums.map(album => (
            <div key={album.id} className="glass-card overflow-hidden">
              <div className="aspect-[4/3] relative cursor-pointer" onClick={() => setSelectedAlbum(album)}>
                {album.coverImage ? (
                  <img src={album.coverImage} alt={album.title} className="h-full w-full object-cover" />
                ) : (
                  <div className="h-full w-full flex items-center justify-center bg-dark-700">
                    <Images className="h-12 w-12 text-gray-600" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-dark-900/80 to-transparent" />
                <div className="absolute bottom-3 left-3 right-3">
                  <h3 className="font-semibold text-white">{album.title}</h3>
                  <div className="text-xs text-gray-300">{allImages.filter(i => i.albumId === album.id).length} images</div>
                </div>
              </div>
              <div className="flex items-center gap-2 p-3">
                <button
                  onClick={() => { setEditingAlbum(album); setAlbumForm({ title: album.title, description: album.description, coverImage: album.coverImage }); setShowAlbumForm(true) }}
                  className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-neon-blue/20 text-xs text-gray-300 hover:text-neon-blue transition-colors"
                >
                  Edit
                </button>
                <button
                  onClick={() => setDeleting(album)}
                  className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-xs text-gray-300 hover:text-red-400 transition-colors"
                >
                  Delete
                </button>
                <span className={`ml-auto pill ${album.published ? 'pill-green' : 'pill-gold'}`}>
                  {album.published ? 'Published' : 'Draft'}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Album form modal */}
      <Modal open={showAlbumForm} onClose={() => setShowAlbumForm(false)} title={editingAlbum ? 'Edit Album' : 'New Album'}>
        <div className="space-y-4">
          <div>
            <label className="neon-label">Album Title *</label>
            <input
              type="text"
              value={albumForm.title}
              onChange={(e) => setAlbumForm({ ...albumForm, title: e.target.value })}
              className="neon-input"
              placeholder="e.g. Annual Day 2025"
            />
          </div>
          <div>
            <label className="neon-label">Description</label>
            <textarea
              value={albumForm.description}
              onChange={(e) => setAlbumForm({ ...albumForm, description: e.target.value })}
              className="neon-input resize-none"
              rows="3"
              placeholder="Brief description of this album"
            />
          </div>
          <div>
            <FileUpload
              folder="gallery/albums"
              value={albumForm.coverImage}
              onChange={(url) => setAlbumForm({ ...albumForm, coverImage: url })}
              label="Cover Image"
              description="Upload a cover image for this album"
            />
          </div>
          <div className="flex justify-end gap-3">
            <button onClick={() => setShowAlbumForm(false)} className="px-4 py-2 rounded-xl border border-white/10 hover:bg-white/5 text-sm text-gray-300">
              Cancel
            </button>
            <button onClick={handleSaveAlbum} disabled={saving} className="neon-btn text-sm !py-2 disabled:opacity-50">
              {saving ? 'Saving...' : 'Save Album'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Album images modal */}
      <Modal open={!!selectedAlbum} onClose={() => setSelectedAlbum(null)} title={selectedAlbum?.title || 'Album'} size="xl">
        {selectedAlbum && (
          <div>
            <div className="mb-6">
              <FileUpload
                folder={`gallery/${selectedAlbum.id}`}
                value=""
                onChange={handleAddImage}
                label="Add Images"
                description="Upload images to this album"
              />
            </div>
            {albumImages.length === 0 ? (
              <EmptyState title="No images yet" description="Upload images to this album." />
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {albumImages.map(img => (
                  <div key={img.id} className="relative group aspect-square rounded-xl overflow-hidden">
                    <img src={img.url} alt={img.caption || 'Gallery image'} className="h-full w-full object-cover" />
                    <button
                      onClick={() => handleDeleteImage(img)}
                      className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/60 text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        onConfirm={handleDeleteAlbum}
        title="Delete Album"
        message={`Are you sure you want to delete "${deleting?.title}"? This will also remove all images in this album.`}
      />
    </div>
  )
}