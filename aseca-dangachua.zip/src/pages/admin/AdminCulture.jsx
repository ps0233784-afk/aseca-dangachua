import AdminCRUD from '../../components/admin/AdminCRUD'
import AdminForm from '../../components/admin/AdminForm'
import { Music } from 'lucide-react'

const fields = [
  { key: 'title', label: 'Title', type: 'text', required: true, placeholder: 'e.g. Santali Language' },
  { key: 'content', label: 'Content', type: 'richText', placeholder: 'Write about this cultural topic...' }
]

export default function AdminCulture() {
  return (
    <AdminCRUD
      collection="culture"
      title="Culture"
      description="Manage Santali culture content"
      searchFields={['title']}
      defaultValues={{ published: true }}
      renderCard={(item) => (
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-neon-emerald/10 text-neon-emerald">
            <Music className="h-5 w-5" />
          </div>
          <div>
            <div className="text-white font-medium">{item.title}</div>
            <div className="text-xs text-gray-500 line-clamp-1" dangerouslySetInnerHTML={{ __html: item.content || '' }} />
          </div>
        </div>
      )}
      formComponent={(props) => <AdminForm fields={fields} {...props} />}
    />
  )
}