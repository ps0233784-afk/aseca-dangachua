import { useState, useEffect } from 'react'
import { useSettings } from '../../contexts/SettingsContext'
import { FileUpload } from '../../components/ui'
import { Save, Settings as SettingsIcon } from 'lucide-react'
import toast from 'react-hot-toast'

export default function AdminSettings() {
  const { settings, saveSettings } = useSettings()
  const [form, setForm] = useState(settings)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    setForm(settings)
  }, [settings])

  const handleChange = (key, value) => {
    setForm(prev => ({ ...prev, [key]: value }))
  }

  const handleSocialChange = (key, value) => {
    setForm(prev => ({
      ...prev,
      socialLinks: { ...prev.socialLinks, [key]: value }
    }))
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const result = await saveSettings(form)
      if (result.success) {
        toast.success('Settings saved successfully!')
      } else {
        toast.error('Failed to save settings.')
      }
    } catch (error) {
      console.error('Error saving settings:', error)
      toast.error('Failed to save settings.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold neon-text mb-1">Website Settings</h1>
          <p className="text-gray-400 text-sm">Manage your website's general settings</p>
        </div>
        <button onClick={handleSave} disabled={saving} className="neon-btn flex items-center gap-2 text-sm !py-2 disabled:opacity-50">
          <Save className="h-4 w-4" /> {saving ? 'Saving...' : 'Save Settings'}
        </button>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Institution Info */}
        <div className="glass-strong p-6 space-y-4">
          <h3 className="font-semibold text-white text-lg flex items-center gap-2">
            <SettingsIcon className="h-5 w-5 text-neon-blue" /> Institution Information
          </h3>
          <div>
            <label className="neon-label">Institution Name</label>
            <input
              type="text"
              value={form.institutionName}
              onChange={(e) => handleChange('institutionName', e.target.value)}
              className="neon-input"
              placeholder="BRANCH ASECA DANGACHUA"
            />
          </div>
          <div>
            <label className="neon-label">Tagline</label>
            <input
              type="text"
              value={form.tagline}
              onChange={(e) => handleChange('tagline', e.target.value)}
              className="neon-input"
              placeholder="Empowering Minds • Preserving Culture • Building the Future"
            />
          </div>
          <div>
            <FileUpload
              folder="settings"
              value={form.logo}
              onChange={(url) => handleChange('logo', url)}
              label="Institution Logo"
              description="Upload your institution logo"
            />
          </div>
          <div>
            <FileUpload
              folder="settings"
              value={form.favicon}
              onChange={(url) => handleChange('favicon', url)}
              label="Favicon"
              description="Upload a small icon (32x32 or 64x64)"
            />
          </div>
        </div>

        {/* Contact Info */}
        <div className="glass-strong p-6 space-y-4">
          <h3 className="font-semibold text-white text-lg">Contact Information</h3>
          <div>
            <label className="neon-label">Contact Email</label>
            <input
              type="email"
              value={form.contactEmail}
              onChange={(e) => handleChange('contactEmail', e.target.value)}
              className="neon-input"
              placeholder="contact@asecadangachua.edu.in"
            />
          </div>
          <div>
            <label className="neon-label">Contact Phone</label>
            <input
              type="tel"
              value={form.contactPhone}
              onChange={(e) => handleChange('contactPhone', e.target.value)}
              className="neon-input"
              placeholder="+91 12345 67890"
            />
          </div>
          <div>
            <label className="neon-label">Address</label>
            <textarea
              value={form.address}
              onChange={(e) => handleChange('address', e.target.value)}
              className="neon-input resize-none"
              rows="3"
              placeholder="Dangachua, Odisha, India"
            />
          </div>
          <div>
            <label className="neon-label">Google Maps Embed URL</label>
            <input
              type="text"
              value={form.mapEmbed}
              onChange={(e) => handleChange('mapEmbed', e.target.value)}
              className="neon-input"
              placeholder="https://www.google.com/maps/embed?pb=..."
            />
            <p className="text-xs text-gray-500 mt-1">Paste the embed URL from Google Maps</p>
          </div>
        </div>

        {/* Social Links */}
        <div className="glass-strong p-6 space-y-4">
          <h3 className="font-semibold text-white text-lg">Social Media Links</h3>
          {[
            { key: 'facebook', label: 'Facebook' },
            { key: 'instagram', label: 'Instagram' },
            { key: 'twitter', label: 'Twitter / X' },
            { key: 'youtube', label: 'YouTube' }
          ].map(social => (
            <div key={social.key}>
              <label className="neon-label">{social.label}</label>
              <input
                type="url"
                value={form.socialLinks?.[social.key] || ''}
                onChange={(e) => handleSocialChange(social.key, e.target.value)}
                className="neon-input"
                placeholder={`https://${social.key}.com/...`}
              />
            </div>
          ))}
        </div>

        {/* Appearance */}
        <div className="glass-strong p-6 space-y-4">
          <h3 className="font-semibold text-white text-lg">Appearance</h3>
          <div>
            <label className="neon-label">Primary Color</label>
            <input
              type="color"
              value={form.primaryColor}
              onChange={(e) => handleChange('primaryColor', e.target.value)}
              className="w-full h-12 rounded-xl bg-white/5 border border-white/10 cursor-pointer"
            />
          </div>
          <div>
            <label className="neon-label">Secondary Color</label>
            <input
              type="color"
              value={form.secondaryColor}
              onChange={(e) => handleChange('secondaryColor', e.target.value)}
              className="w-full h-12 rounded-xl bg-white/5 border border-white/10 cursor-pointer"
            />
          </div>
          <div>
            <label className="neon-label">Accent Color</label>
            <input
              type="color"
              value={form.accentColor}
              onChange={(e) => handleChange('accentColor', e.target.value)}
              className="w-full h-12 rounded-xl bg-white/5 border border-white/10 cursor-pointer"
            />
          </div>
          <div>
            <label className="neon-label">Footer Text</label>
            <input
              type="text"
              value={form.footerText}
              onChange={(e) => handleChange('footerText', e.target.value)}
              className="neon-input"
              placeholder="© 2025 BRANCH ASECA DANGACHUA. All rights reserved."
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end mt-6">
        <button onClick={handleSave} disabled={saving} className="neon-btn flex items-center gap-2 disabled:opacity-50">
          <Save className="h-4 w-4" /> {saving ? 'Saving...' : 'Save Settings'}
        </button>
      </div>
    </div>
  )
}