import AdminCRUD from '../../components/admin/AdminCRUD'
import AdminForm from '../../components/admin/AdminForm'
import { Newspaper } from 'lucide-react'

const fields = [
  { key: 'title', label: 'Title', type: 'text', required: true, placeholder: 'Enter news title' },
  { key: 'category', label: 'Category', type: 'select', options: ['News', 'Notice', 'Circular', 'Event', 'Announcement'] },
  { key: 'thumbnail', label: 'Thumbnail', type: 'file', folder: 'news', description: 'Upload news thumbnail image' },
  { key: 'content', label: 'Content', type: 'richText', placeholder: 'Write your news content...' },
  { key: 'date', label: 'Date', type: 'date' },
  { key: 'pinned', label: 'Pin to top', type: 'toggle', help: 'Pinned items appear first' }
]

export default function AdminNews() {
  return (
    <AdminCRUD
      collection="news"
      title="News & Events"
      description="Manage news, notices, circulars, and events"
      searchFields={['title', 'category']}
      defaultValues={{ published: true, pinned: false }}
      renderCard={(item) => (
        <div>
          <div className="flex items-center gap-3 mb-2">
            {item.thumbnail ? (
              <img src={item.thumbnail} alt={item.title} className="w-12 h-12 rounded-lg object-cover" />
            ) : (
              <div className="w-12 h-12 rounded-lg bg-dark-700 flex items-center justify-center">
                <Newspaper className="h-6 w-6 text-gray-500" />
              </div>
            )}
            <div>
              <div className="text-white font-medium line-clamp-1">{item.title}</div>
              <div className="text-xs text-gray-500">{item.category}</div>
            </div>
          </div>
          {item.pinned && <span className="pill pill-gold">Pinned</span>}
        </div>
      )}
      formComponent={(props) => <AdminForm fields={fields} {...props} />}
    />
  )
}