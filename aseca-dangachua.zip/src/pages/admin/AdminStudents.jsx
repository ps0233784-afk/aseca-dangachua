import AdminCRUD from '../../components/admin/AdminCRUD'
import AdminForm from '../../components/admin/AdminForm'
import { UserSquare } from 'lucide-react'

const fields = [
  { key: 'name', label: 'Full Name', type: 'text', required: true, placeholder: 'Enter student name' },
  { key: 'studentId', label: 'Student ID', type: 'text', required: true, placeholder: 'e.g. ASC-2025-0001' },
  { key: 'admissionNumber', label: 'Admission Number', type: 'text', placeholder: 'Admission number' },
  { key: 'photo', label: 'Photo', type: 'file', folder: 'students', description: 'Upload student photo' },
  { key: 'fatherName', label: "Father's Name", type: 'text', placeholder: "Father's name" },
  { key: 'motherName', label: "Mother's Name", type: 'text', placeholder: "Mother's name" },
  { key: 'gender', label: 'Gender', type: 'select', options: ['Male', 'Female', 'Other'] },
  { key: 'dob', label: 'Date of Birth', type: 'date' },
  { key: 'school', label: 'School', type: 'text', placeholder: 'School name' },
  { key: 'class', label: 'Class', type: 'text', placeholder: 'e.g. Class 5' },
  { key: 'section', label: 'Section', type: 'text', placeholder: 'e.g. A' },
  { key: 'rollNumber', label: 'Roll Number', type: 'text', placeholder: 'Roll number' },
  { key: 'address', label: 'Address', type: 'textarea', rows: 3, placeholder: 'Home address' },
  { key: 'contact', label: 'Contact Number', type: 'tel', placeholder: '+91 12345 67890' },
  { key: 'bloodGroup', label: 'Blood Group', type: 'select', options: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] },
  { key: 'admissionDate', label: 'Admission Date', type: 'date' }
]

export default function AdminStudents() {
  return (
    <AdminCRUD
      collection="students"
      title="Students"
      description="Manage student records"
      searchFields={['name', 'studentId', 'admissionNumber', 'fatherName']}
      defaultValues={{ published: true }}
      renderCard={(student) => (
        <div className="flex items-center gap-3">
          {student.photo ? (
            <img src={student.photo} alt={student.name} className="w-12 h-12 rounded-full object-cover" />
          ) : (
            <div className="w-12 h-12 rounded-full bg-dark-700 flex items-center justify-center">
              <UserSquare className="h-6 w-6 text-gray-500" />
            </div>
          )}
          <div>
            <div className="text-white font-medium">{student.name}</div>
            <div className="text-sm text-neon-blue">{student.studentId}</div>
            <div className="text-xs text-gray-500">{student.class} {student.section}</div>
          </div>
        </div>
      )}
      formComponent={(props) => <AdminForm fields={fields} {...props} />}
    />
  )
}