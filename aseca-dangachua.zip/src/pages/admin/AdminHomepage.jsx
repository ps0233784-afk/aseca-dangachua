import { useState, useEffect } from 'react'
import { useSettings } from '../../contexts/SettingsContext'
import { FileUpload, RichTextEditor } from '../../components/ui'
import { Save, Eye, Home, Image as ImageIcon, Type, Link2, BarChart3 } from 'lucide-react'
import toast from 'react-hot-toast'

export default function AdminHomepage() {
  const { homepage, saveHomepage } = useSettings()
  const [form, setForm] = useState({
    hero: {
      heading: 'BRANCH ASECA DANGACHUA',
      tagline: 'Empowering Minds • Preserving Culture • Building the Future',
      background: '',
      button1Text: 'Explore Institution',
      button1Link: '/about',
      button2Text: 'View Results',
      button2Link: '/results'
    },
    stats: { schools: 0, students: 0, teachers: 0, passRate: 0 },
    about: { title: 'About Our Institution', content: '', image: '' },
    features: [],
    footerText: ''
  })
  const [saving, setSaving] = useState(false)
  const [activeTab, setActiveTab] = useState('hero')

  useEffect(() => {
    if (homepage) {
      setForm({
        hero: { ...form.hero, ...homepage.hero },
        stats: { ...form.stats, ...homepage.stats },
        about: { ...form.about, ...homepage.about },
        features: homepage.features || [],
        footerText: homepage.footerText || ''
      })
    }
  }, [homepage])

  const handleChange = (section, field, value) => {
    setForm(prev => ({
      ...prev,
      [section]: { ...prev[section], [field]: value }
    }))
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const result = await saveHomepage(form)
      if (result.success) {
        toast.success('Changes saved successfully!')
      } else {
        toast.error('Failed to save changes.')
      }
    } catch (error) {
      console.error('Error saving homepage:', error)
      toast.error('Failed to save changes.')
    } finally {
      setSaving(false)
    }
  }

  const tabs = [
    { id: 'hero', label: 'Hero Section', icon: Home },
    { id: 'stats', label: 'Statistics', icon: BarChart3 },
    { id: 'about', label: 'About Section', icon: Type },
    { id: 'footer', label: 'Footer', icon: Type }
  ]

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold neon-text mb-2">Homepage Editor</h1>
          <p className="text-gray-400">Edit the content shown on your public homepage</p>
        </div>
        <div className="flex gap-3">
          <a href="/" target="_blank" rel="noopener noreferrer" className="neon-btn-secondary flex items-center gap-2 text-sm !py-2">
            <Eye className="h-4 w-4" /> Preview
          </a>
          <button onClick={handleSave} disabled={saving} className="neon-btn flex items-center gap-2 text-sm !py-2 disabled:opacity-50">
            <Save className="h-4 w-4" /> {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-neon-blue/10 text-neon-blue border border-neon-blue/30'
                : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10 border border-white/10'
            }`}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="glass-strong p-6">
        {activeTab === 'hero' && (
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-white text-lg mb-4">Hero Background</h3>
              <FileUpload
                folder="homepage/hero"
                value={form.hero.background}
                onChange={(url) => handleChange('hero', 'background', url)}
                label="Background Image"
                description="Upload a Santali cultural or educational background image"
              />
            </div>

            <div>
              <h3 className="font-semibold text-white text-lg mb-4">Hero Text</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="neon-label">Heading</label>
                  <input
                    type="text"
                    value={form.hero.heading}
                    onChange={(e) => handleChange('hero', 'heading', e.target.value)}
                    className="neon-input"
                    placeholder="BRANCH ASECA DANGACHUA"
                  />
                </div>
                <div>
                  <label className="neon-label">Tagline</label>
                  <input
                    type="text"
                    value={form.hero.tagline}
                    onChange={(e) => handleChange('hero', 'tagline', e.target.value)}
                    className="neon-input"
                    placeholder="Empowering Minds • Preserving Culture • Building the Future"
                  />
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-white text-lg mb-4">Buttons</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="neon-label">Button 1 Text</label>
                  <input
                    type="text"
                    value={form.hero.button1Text}
                    onChange={(e) => handleChange('hero', 'button1Text', e.target.value)}
                    className="neon-input"
                    placeholder="Explore Institution"
                  />
                </div>
                <div>
                  <label className="neon-label">Button 1 Link</label>
                  <input
                    type="text"
                    value={form.hero.button1Link}
                    onChange={(e) => handleChange('hero', 'button1Link', e.target.value)}
                    className="neon-input"
                    placeholder="/about"
                  />
                </div>
                <div>
                  <label className="neon-label">Button 2 Text</label>
                  <input
                    type="text"
                    value={form.hero.button2Text}
                    onChange={(e) => handleChange('hero', 'button2Text', e.target.value)}
                    className="neon-input"
                    placeholder="View Results"
                  />
                </div>
                <div>
                  <label className="neon-label">Button 2 Link</label>
                  <input
                    type="text"
                    value={form.hero.button2Link}
                    onChange={(e) => handleChange('hero', 'button2Link', e.target.value)}
                    className="neon-input"
                    placeholder="/results"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'stats' && (
          <div>
            <h3 className="font-semibold text-white text-lg mb-4">Statistics</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { key: 'schools', label: 'Number of Schools' },
                { key: 'students', label: 'Number of Students' },
                { key: 'teachers', label: 'Number of Teachers' },
                { key: 'passRate', label: 'Pass Rate (%)' }
              ].map(field => (
                <div key={field.key}>
                  <label className="neon-label">{field.label}</label>
                  <input
                    type="number"
                    value={form.stats[field.key]}
                    onChange={(e) => handleChange('stats', field.key, Number(e.target.value))}
                    className="neon-input"
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'about' && (
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-white text-lg mb-4">About Section</h3>
              <div className="mb-4">
                <label className="neon-label">Title</label>
                <input
                  type="text"
                  value={form.about.title}
                  onChange={(e) => handleChange('about', 'title', e.target.value)}
                  className="neon-input"
                  placeholder="About Our Institution"
                />
              </div>
              <div className="mb-4">
                <FileUpload
                  folder="homepage/about"
                  value={form.about.image}
                  onChange={(url) => handleChange('about', 'image', url)}
                  label="About Image"
                  description="Upload an image of your institution"
                />
              </div>
              <RichTextEditor
                value={form.about.content}
                onChange={(value) => handleChange('about', 'content', value)}
                label="About Content"
                placeholder="Write about your institution..."
              />
            </div>
          </div>
        )}

        {activeTab === 'footer' && (
          <div>
            <h3 className="font-semibold text-white text-lg mb-4">Footer</h3>
            <div>
              <label className="neon-label">Footer Text</label>
              <input
                type="text"
                value={form.footerText}
                onChange={(e) => setForm(prev => ({ ...prev, footerText: e.target.value }))}
                className="neon-input"
                placeholder="© 2025 BRANCH ASECA DANGACHUA. All rights reserved."
              />
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-end mt-6">
        <button onClick={handleSave} disabled={saving} className="neon-btn flex items-center gap-2 disabled:opacity-50">
          <Save className="h-4 w-4" /> {saving ? 'Saving...' : 'Save Changes'}
        </button>
      </div>
    </div>
  )
}