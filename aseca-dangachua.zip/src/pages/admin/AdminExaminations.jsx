import AdminCRUD from '../../components/admin/AdminCRUD'
import AdminForm from '../../components/admin/AdminForm'
import { FileSpreadsheet } from 'lucide-react'

const fields = [
  { key: 'name', label: 'Exam Name', type: 'text', required: true, placeholder: 'e.g. Annual Examination 2025' },
  { key: 'class', label: 'Class', type: 'text', placeholder: 'e.g. Class 5' },
  { key: 'subject', label: 'Subject', type: 'text', placeholder: 'e.g. Mathematics' },
  { key: 'date', label: 'Exam Date', type: 'date' },
  { key: 'time', label: 'Time', type: 'text', placeholder: 'e.g. 10:00 AM - 1:00 PM' },
  { key: 'venue', label: 'Venue', type: 'text', placeholder: 'e.g. Main Hall' },
  { key: 'instructions', label: 'Instructions', type: 'richText', placeholder: 'Exam instructions...' },
  { key: 'admitCardUrl', label: 'Admit Card', type: 'file', folder: 'exams/admit-cards', accept: 'application/pdf', description: 'Upload admit card PDF' }
]

export default function AdminExaminations() {
  return (
    <AdminCRUD
      collection="examinations"
      title="Examinations"
      description="Manage exams, timetables, and admit cards"
      searchFields={['name', 'class', 'subject']}
      defaultValues={{ published: true }}
      renderCard={(exam) => (
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-neon-blue/10 text-neon-blue">
              <FileSpreadsheet className="h-5 w-5" />
            </div>
            <div>
              <div className="text-white font-medium">{exam.name}</div>
              <div className="text-xs text-gray-500">{exam.class} • {exam.subject}</div>
            </div>
          </div>
          {exam.date && <div className="text-xs text-gray-400">Date: {new Date(exam.date).toLocaleDateString()}</div>}
        </div>
      )}
      formComponent={(props) => <AdminForm fields={fields} {...props} />}
    />
  )
}