import { useState } from 'react'
import { FileUpload, Loader, EmptyState, ConfirmDialog } from '../../components/ui'
import { FolderOpen, Trash2, FileText, Image as ImageIcon, Search } from 'lucide-react'
import { listFiles, deleteFile } from '../../services/storageService'
import toast from 'react-hot-toast'

export default function AdminMedia() {
  const [files, setFiles] = useState([])
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [deleting, setDeleting] = useState(null)

  const loadFiles = async () => {
    setLoading(true)
    try {
      const allFiles = []
      const folders = ['uploads', 'homepage', 'about', 'managing-body', 'schools', 'teachers', 'students', 'news', 'gallery', 'library', 'exams', 'results', 'culture']
      for (const folder of folders) {
        try {
          const items = await listFiles(folder)
          allFiles.push(...items)
        } catch (e) {
          // Folder may not exist
        }
      }
      setFiles(allFiles)
    } catch (error) {
      console.error('Error loading files:', error)
      toast.error('Failed to load media files.')
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!deleting) return
    try {
      const success = await deleteFile(deleting.path)
      if (success) {
        toast.success('File deleted successfully!')
        setFiles(files.filter(f => f.path !== deleting.path))
      } else {
        toast.error('Failed to delete file.')
      }
      setDeleting(null)
    } catch (error) {
      console.error('Error deleting file:', error)
      toast.error('Failed to delete file.')
    }
  }

  const filtered = files.filter(f => {
    if (!search) return true
    return f.name.toLowerCase().includes(search.toLowerCase())
  })

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold neon-text mb-1">Media Manager</h1>
          <p className="text-gray-400 text-sm">Manage all uploaded files and images</p>
        </div>
        <button onClick={loadFiles} className="neon-btn-secondary text-sm !py-2.5">
          Refresh Files
        </button>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search files..."
          className="neon-input !pl-10"
        />
      </div>

      {loading ? <Loader /> : filtered.length === 0 ? (
        <EmptyState title="No files found" description="Upload files or refresh to see your media." />
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map((file, i) => (
            <div key={i} className="glass-card overflow-hidden group">
              <div className="aspect-square bg-dark-700 flex items-center justify-center overflow-hidden">
                {file.name.match(/\.(jpg|jpeg|png|gif|webp|svg)$/i) ? (
                  <img src={file.url} alt={file.name} className="h-full w-full object-cover" />
                ) : (
                  <div className="text-center">
                    <FileText className="h-10 w-10 text-neon-blue mx-auto mb-2" />
                    <span className="text-xs text-gray-500">PDF</span>
                  </div>
                )}
              </div>
              <div className="p-3">
                <div className="text-xs text-gray-300 truncate mb-2">{file.name}</div>
                <div className="flex items-center justify-between">
                  <a
                    href={file.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-neon-blue hover:underline"
                  >
                    View
                  </a>
                  <button
                    onClick={() => setDeleting(file)}
                    className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        onConfirm={handleDelete}
        title="Delete File"
        message={`Are you sure you want to delete "${deleting?.name}"? This cannot be undone.`}
      />
    </div>
  )
}