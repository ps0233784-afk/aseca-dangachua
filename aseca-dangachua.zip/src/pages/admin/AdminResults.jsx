import AdminCRUD from '../../components/admin/AdminCRUD'
import AdminForm from '../../components/admin/AdminForm'
import { Award } from 'lucide-react'

const fields = [
  { key: 'studentName', label: 'Student Name', type: 'text', required: true, placeholder: 'Enter student name' },
  { key: 'rollNumber', label: 'Roll Number', type: 'text', required: true, placeholder: 'Enter roll number' },
  { key: 'studentId', label: 'Student ID', type: 'text', required: true, placeholder: 'Enter student ID' },
  { key: 'examName', label: 'Exam Name', type: 'text', required: true, placeholder: 'e.g. Annual Examination 2025' },
  { key: 'class', label: 'Class', type: 'text', placeholder: 'e.g. Class 5' },
  { key: 'photo', label: 'Student Photo', type: 'file', folder: 'results', description: 'Upload student photo' },
  { key: 'rank', label: 'Rank', type: 'number', placeholder: 'e.g. 1' }
]

export default function AdminResults() {
  return (
    <AdminCRUD
      collection="results"
      title="Results"
      description="Manage student results and marksheets"
      searchFields={['studentName', 'rollNumber', 'studentId']}
      defaultValues={{ published: true }}
      renderCard={(result) => (
        <div className="flex items-center gap-3">
          {result.photo ? (
            <img src={result.photo} alt={result.studentName} className="w-12 h-12 rounded-full object-cover" />
          ) : (
            <div className="w-12 h-12 rounded-full bg-dark-700 flex items-center justify-center">
              <Award className="h-6 w-6 text-gray-500" />
            </div>
          )}
          <div>
            <div className="text-white font-medium">{result.studentName}</div>
            <div className="text-sm text-neon-blue">Roll: {result.rollNumber}</div>
            <div className="text-xs text-gray-500">{result.examName} • {result.class}</div>
          </div>
        </div>
      )}
      formComponent={(props) => <AdminForm fields={fields} {...props} />}
    />
  )
}