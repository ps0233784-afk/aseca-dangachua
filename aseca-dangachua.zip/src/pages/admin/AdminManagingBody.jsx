import AdminCRUD from '../../components/admin/AdminCRUD'
import AdminForm from '../../components/admin/AdminForm'
import { Users } from 'lucide-react'

const fields = [
  { key: 'name', label: 'Full Name', type: 'text', required: true, placeholder: 'Enter member name' },
  { key: 'designation', label: 'Designation', type: 'text', required: true, placeholder: 'e.g. President, Secretary' },
  { key: 'qualification', label: 'Qualification', type: 'text', placeholder: 'e.g. M.A., B.Ed.' },
  { key: 'photo', label: 'Photo', type: 'file', folder: 'managing-body', description: 'Upload member photo' },
  { key: 'biography', label: 'Biography', type: 'textarea', rows: 4, placeholder: 'Brief biography...' },
  { key: 'email', label: 'Email', type: 'email', placeholder: 'member@email.com' },
  { key: 'phone', label: 'Phone', type: 'tel', placeholder: '+91 12345 67890' },
  { key: 'displayOrder', label: 'Display Order', type: 'number', placeholder: '1, 2, 3...' }
]

export default function AdminManagingBody() {
  return (
    <AdminCRUD
      collection="managingBody"
      title="Managing Body"
      description="Manage the leadership team members"
      searchFields={['name', 'designation']}
      defaultValues={{ displayOrder: 1, published: true }}
      renderCard={(member) => (
        <div className="flex items-center gap-3">
          {member.photo ? (
            <img src={member.photo} alt={member.name} className="w-12 h-12 rounded-full object-cover" />
          ) : (
            <div className="w-12 h-12 rounded-full bg-dark-700 flex items-center justify-center">
              <Users className="h-6 w-6 text-gray-500" />
            </div>
          )}
          <div>
            <div className="text-white font-medium">{member.name}</div>
            <div className="text-sm text-neon-blue">{member.designation}</div>
          </div>
        </div>
      )}
      formComponent={(props) => <AdminForm fields={fields} {...props} />}
    />
  )
}