import { useCollection } from '../../hooks/useCollection'
import { StatCard, Loader } from '../../components/ui'
import {
  School, Users, GraduationCap, ClipboardCheck, FileSpreadsheet, Award,
  BookOpen, Newspaper, Images, Mail, TrendingUp, AlertCircle
} from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

export default function AdminDashboard() {
  const { data: schools } = useCollection('schools')
  const { data: students } = useCollection('students')
  const { data: teachers } = useCollection('teachers')
  const { data: attendance } = useCollection('teacherAttendance')
  const { data: exams } = useCollection('examinations')
  const { data: results } = useCollection('results')
  const { data: library } = useCollection('library')
  const { data: news } = useCollection('news')
  const { data: albums } = useCollection('galleryAlbums')
  const { data: messages } = useCollection('contactMessages')

  const today = new Date().toISOString().split('T')[0]
  const todayAttendance = attendance.filter(a => {
    const d = a.date?.seconds ? new Date(a.date.seconds * 1000) : new Date(a.date)
    return d.toISOString().split('T')[0] === today
  })
  const presentToday = todayAttendance.filter(a => a.status === 'present').length

  const attendanceData = [
    { name: 'Present', value: attendance.filter(a => a.status === 'present').length },
    { name: 'Absent', value: attendance.filter(a => a.status === 'absent').length },
    { name: 'Leave', value: attendance.filter(a => a.status === 'leave').length },
    { name: 'Half Day', value: attendance.filter(a => a.status === 'halfDay').length }
  ]

  const COLORS = ['#00ff9d', '#ff4444', '#ffd700', '#a855f7']

  const stats = [
    { icon: School, label: 'Schools', value: schools.length, color: 'blue' },
    { icon: Users, label: 'Students', value: students.length, color: 'emerald' },
    { icon: GraduationCap, label: 'Teachers', value: teachers.length, color: 'violet' },
    { icon: ClipboardCheck, label: "Today's Attendance", value: `${presentToday}/${todayAttendance.length}`, color: 'gold' },
    { icon: FileSpreadsheet, label: 'Examinations', value: exams.length, color: 'magenta' },
    { icon: Award, label: 'Results', value: results.length, color: 'blue' },
    { icon: BookOpen, label: 'Library Resources', value: library.length, color: 'emerald' },
    { icon: Newspaper, label: 'News & Events', value: news.length, color: 'violet' },
    { icon: Images, label: 'Gallery Albums', value: albums.length, color: 'gold' },
    { icon: Mail, label: 'Messages', value: messages.filter(m => m.status === 'new').length, color: 'magenta' }
  ]

  const recentMessages = messages.slice(0, 5)

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold neon-text mb-2">Dashboard Overview</h1>
        <p className="text-gray-400">Welcome back! Here's what's happening at your institution.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
        {stats.map((stat, i) => (
          <StatCard key={i} icon={stat.icon} label={stat.label} value={stat.value} color={stat.color} delay={i * 0.05} />
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6 mb-8">
        {/* Attendance Chart */}
        <div className="glass-card p-6">
          <h3 className="font-semibold text-white text-lg mb-4 flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-neon-blue" /> Attendance Overview
          </h3>
          {attendance.length === 0 ? (
            <div className="text-center text-gray-500 py-8">No attendance data yet</div>
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={attendanceData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {attendanceData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Recent Messages */}
        <div className="glass-card p-6">
          <h3 className="font-semibold text-white text-lg mb-4 flex items-center gap-2">
            <Mail className="h-5 w-5 text-neon-gold" /> Recent Messages
          </h3>
          {recentMessages.length === 0 ? (
            <div className="text-center text-gray-500 py-8">No messages yet</div>
          ) : (
            <div className="space-y-3">
              {recentMessages.map(msg => (
                <div key={msg.id} className="p-3 rounded-xl bg-white/5">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-white">{msg.name}</span>
                    <span className="text-xs text-gray-500">{msg.createdAt ? new Date(msg.createdAt).toLocaleDateString() : ''}</span>
                  </div>
                  <p className="text-sm text-gray-400 line-clamp-2">{msg.message}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="glass-card p-6">
        <h3 className="font-semibold text-white text-lg mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Add School', path: '/admin/schools', icon: School },
            { label: 'Add Teacher', path: '/admin/teachers', icon: GraduationCap },
            { label: 'Add Student', path: '/admin/students', icon: Users },
            { label: 'Mark Attendance', path: '/admin/attendance', icon: ClipboardCheck }
          ].map((action, i) => (
            <a
              key={i}
              href={action.path}
              className="p-4 rounded-xl bg-white/5 hover:bg-neon-blue/10 border border-white/10 hover:border-neon-blue/30 transition-all text-center"
            >
              <action.icon className="h-6 w-6 text-neon-blue mx-auto mb-2" />
              <span className="text-sm text-gray-300">{action.label}</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  )
}