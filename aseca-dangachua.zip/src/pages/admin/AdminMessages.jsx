import { useState } from 'react'
import { useCollection } from '../../hooks/useCollection'
import { updateDocument, deleteDocument } from '../../services/firestoreService'
import { Loader, EmptyState, ConfirmDialog } from '../../components/ui'
import { Mail, Trash2, CheckCircle2, User, MessageSquare } from 'lucide-react'
import { formatDateTime } from '../../utils/helpers'
import toast from 'react-hot-toast'

export default function AdminMessages() {
  const { data: messages, loading, refetch } = useCollection('contactMessages', [], true)
  const [deleting, setDeleting] = useState(null)

  const handleMarkRead = async (message) => {
    try {
      await updateDocument('contactMessages', message.id, { status: 'read' })
      toast.success('Marked as read')
      refetch()
    } catch (error) {
      console.error('Error updating message:', error)
      toast.error('Failed to update message.')
    }
  }

  const handleDelete = async () => {
    if (!deleting) return
    try {
      await deleteDocument('contactMessages', deleting.id)
      toast.success('Message deleted successfully!')
      setDeleting(null)
      refetch()
    } catch (error) {
      console.error('Error deleting message:', error)
      toast.error('Failed to delete message.')
    }
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold neon-text mb-1">Messages</h1>
        <p className="text-gray-400 text-sm">Messages from your website contact form</p>
      </div>

      {loading ? <Loader /> : messages.length === 0 ? (
        <EmptyState title="No messages yet" description="Messages from the contact form will appear here." />
      ) : (
        <div className="space-y-4">
          {messages.map(message => (
            <div key={message.id} className={`glass-card p-5 ${message.status === 'new' ? 'border-neon-blue/30' : ''}`}>
              <div className="flex items-start justify-between gap-4 mb-3">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-neon-blue/10 text-neon-blue">
                    <User className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="font-medium text-white">{message.name}</div>
                    <div className="text-xs text-gray-500">{message.email}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {message.status === 'new' && <span className="pill pill-blue">New</span>}
                  <span className="text-xs text-gray-500">{formatDateTime(message.createdAt)}</span>
                </div>
              </div>
              {message.subject && (
                <div className="text-sm text-neon-blue font-medium mb-2">{message.subject}</div>
              )}
              <p className="text-sm text-gray-300 mb-4">{message.message}</p>
              <div className="flex items-center gap-2">
                {message.status === 'new' && (
                  <button
                    onClick={() => handleMarkRead(message)}
                    className="px-3 py-1.5 rounded-lg bg-neon-emerald/10 text-neon-emerald text-xs hover:bg-neon-emerald/20 transition-colors flex items-center gap-1"
                  >
                    <CheckCircle2 className="h-3 w-3" /> Mark as Read
                  </button>
                )}
                <button
                  onClick={() => setDeleting(message)}
                  className="px-3 py-1.5 rounded-lg bg-red-500/10 text-red-400 text-xs hover:bg-red-500/20 transition-colors flex items-center gap-1"
                >
                  <Trash2 className="h-3 w-3" /> Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        onConfirm={handleDelete}
        title="Delete Message"
        message={`Are you sure you want to delete this message from "${deleting?.name}"?`}
      />
    </div>
  )
}