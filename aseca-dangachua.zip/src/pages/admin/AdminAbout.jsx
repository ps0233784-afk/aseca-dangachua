import { useState, useEffect } from 'react'
import { useSettings } from '../../contexts/SettingsContext'
import { RichTextEditor, FileUpload } from '../../components/ui'
import { Save, Eye } from 'lucide-react'
import toast from 'react-hot-toast'

export default function AdminAbout() {
  const { homepage, saveHomepage } = useSettings()
  const [form, setForm] = useState({ title: 'About Our Institution', content: '', image: '' })
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (homepage?.about) {
      setForm({ ...form, ...homepage.about })
    }
  }, [homepage])

  const handleSave = async () => {
    setSaving(true)
    try {
      const result = await saveHomepage({ ...homepage, about: form })
      if (result.success) {
        toast.success('Changes saved successfully!')
      } else {
        toast.error('Failed to save changes.')
      }
    } catch (error) {
      console.error('Error saving about:', error)
      toast.error('Failed to save changes.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold neon-text mb-2">About Page Editor</h1>
          <p className="text-gray-400">Edit the content shown on your About page</p>
        </div>
        <div className="flex gap-3">
          <a href="/about" target="_blank" rel="noopener noreferrer" className="neon-btn-secondary flex items-center gap-2 text-sm !py-2">
            <Eye className="h-4 w-4" /> Preview
          </a>
          <button onClick={handleSave} disabled={saving} className="neon-btn flex items-center gap-2 text-sm !py-2 disabled:opacity-50">
            <Save className="h-4 w-4" /> {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      <div className="glass-strong p-6 space-y-6">
        <div>
          <label className="neon-label">Page Title</label>
          <input
            type="text"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="neon-input"
            placeholder="About Our Institution"
          />
        </div>

        <div>
          <FileUpload
            folder="about"
            value={form.image}
            onChange={(url) => setForm({ ...form, image: url })}
            label="About Image"
            description="Upload an image of your institution"
          />
        </div>

        <div>
          <RichTextEditor
            value={form.content}
            onChange={(value) => setForm({ ...form, content: value })}
            label="About Content"
            placeholder="Write about your institution..."
          />
        </div>
      </div>

      <div className="flex justify-end mt-6">
        <button onClick={handleSave} disabled={saving} className="neon-btn flex items-center gap-2 disabled:opacity-50">
          <Save className="h-4 w-4" /> {saving ? 'Saving...' : 'Save Changes'}
        </button>
      </div>
    </div>
  )
}