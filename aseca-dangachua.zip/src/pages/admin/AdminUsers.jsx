import { useState } from 'react'
import { useCollection } from '../../hooks/useCollection'
import { updateDocument } from '../../services/firestoreService'
import { Loader, EmptyState, SearchBar } from '../../components/ui'
import { Users, Shield, ShieldCheck, ShieldAlert, User } from 'lucide-react'
import toast from 'react-hot-toast'

const ROLES = [
  { value: 'superadmin', label: 'Super Admin', icon: ShieldAlert, color: 'text-red-400' },
  { value: 'admin', label: 'Admin', icon: ShieldCheck, color: 'text-neon-blue' },
  { value: 'editor', label: 'Editor', icon: Shield, color: 'text-neon-emerald' },
  { value: 'viewer', label: 'Viewer', icon: User, color: 'text-gray-400' }
]

export default function AdminUsers() {
  const { data: users, loading, refetch } = useCollection('users', [], true)
  const [search, setSearch] = useState('')
  const [updating, setUpdating] = useState(null)

  const filtered = users.filter(user => {
    if (!search) return true
    const q = search.toLowerCase()
    return user.email?.toLowerCase().includes(q) || user.name?.toLowerCase().includes(q)
  })

  const handleRoleChange = async (user, role) => {
    setUpdating(user.id)
    try {
      await updateDocument('users', user.id, { role })
      toast.success(`Role updated to ${role}`)
      refetch()
    } catch (error) {
      console.error('Error updating role:', error)
      toast.error('Failed to update role.')
    } finally {
      setUpdating(null)
    }
  }

  const handleToggleActive = async (user) => {
    setUpdating(user.id)
    try {
      await updateDocument('users', user.id, { active: !user.active })
      toast.success(user.active ? 'User disabled' : 'User enabled')
      refetch()
    } catch (error) {
      console.error('Error updating user:', error)
      toast.error('Failed to update user.')
    } finally {
      setUpdating(null)
    }
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold neon-text mb-1">User Management</h1>
        <p className="text-gray-400 text-sm">Manage user roles and access</p>
      </div>

      <div className="mb-6">
        <SearchBar value={search} onChange={setSearch} placeholder="Search users by name or email..." />
      </div>

      {loading ? <Loader /> : filtered.length === 0 ? (
        <EmptyState title="No users found" description="Users will appear here." />
      ) : (
        <div className="glass-strong overflow-hidden">
          <div className="table-responsive">
            <table className="table-glass">
              <thead>
                <tr>
                  <th>User</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(user => {
                  const roleInfo = ROLES.find(r => r.value === user.role) || ROLES[3]
                  return (
                    <tr key={user.id}>
                      <td>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-neon-blue to-violet-500 flex items-center justify-center font-bold text-sm">
                            {user.name?.[0] || user.email?.[0]?.toUpperCase() || 'U'}
                          </div>
                          <div>
                            <div className="text-white font-medium">{user.name || '—'}</div>
                            <div className="text-xs text-gray-500">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <span className={`pill ${roleInfo.color} bg-white/5 border-white/10`}>
                          <roleInfo.icon className="h-3 w-3 mr-1" />
                          {roleInfo.label}
                        </span>
                      </td>
                      <td>
                        <span className={`pill ${user.active ? 'pill-green' : 'pill-gold'}`}>
                          {user.active ? 'Active' : 'Disabled'}
                        </span>
                      </td>
                      <td>
                        <div className="flex items-center gap-2">
                          <select
                            value={user.role}
                            onChange={(e) => handleRoleChange(user, e.target.value)}
                            disabled={updating === user.id}
                            className="neon-select !py-1.5 !px-2 text-xs w-32"
                          >
                            {ROLES.map(role => (
                              <option key={role.value} value={role.value}>{role.label}</option>
                            ))}
                          </select>
                          <button
                            onClick={() => handleToggleActive(user)}
                            disabled={updating === user.id}
                            className={`px-3 py-1.5 rounded-lg text-xs transition-colors ${
                              user.active
                                ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20'
                                : 'bg-neon-emerald/10 text-neon-emerald hover:bg-neon-emerald/20'
                            }`}
                          >
                            {user.active ? 'Disable' : 'Enable'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}