import AdminCRUD from '../../components/admin/AdminCRUD'
import AdminForm from '../../components/admin/AdminForm'
import { GraduationCap } from 'lucide-react'

const fields = [
  { key: 'name', label: 'Full Name', type: 'text', required: true, placeholder: 'Enter teacher name' },
  { key: 'photo', label: 'Photo', type: 'file', folder: 'teachers', description: 'Upload teacher photo' },
  { key: 'designation', label: 'Designation', type: 'text', required: true, placeholder: 'e.g. Teacher, Headmaster' },
  { key: 'subject', label: 'Subject', type: 'text', placeholder: 'e.g. Mathematics' },
  { key: 'qualification', label: 'Qualification', type: 'text', placeholder: 'e.g. M.Sc., B.Ed.' },
  { key: 'school', label: 'School', type: 'text', placeholder: 'School name' },
  { key: 'experience', label: 'Experience (Years)', type: 'number', placeholder: '0' },
  { key: 'email', label: 'Email', type: 'email', placeholder: 'teacher@email.com' },
  { key: 'phone', label: 'Phone', type: 'tel', placeholder: '+91 12345 67890' }
]

export default function AdminTeachers() {
  return (
    <AdminCRUD
      collection="teachers"
      title="Teachers"
      description="Manage your teaching staff"
      searchFields={['name', 'designation', 'subject']}
      defaultValues={{ experience: 0, published: true }}
      renderCard={(teacher) => (
        <div className="flex items-center gap-3">
          {teacher.photo ? (
            <img src={teacher.photo} alt={teacher.name} className="w-12 h-12 rounded-full object-cover" />
          ) : (
            <div className="w-12 h-12 rounded-full bg-dark-700 flex items-center justify-center">
              <GraduationCap className="h-6 w-6 text-gray-500" />
            </div>
          )}
          <div>
            <div className="text-white font-medium">{teacher.name}</div>
            <div className="text-sm text-neon-blue">{teacher.designation}</div>
            <div className="text-xs text-gray-500">{teacher.subject}</div>
          </div>
        </div>
      )}
      formComponent={(props) => <AdminForm fields={fields} {...props} />}
    />
  )
}