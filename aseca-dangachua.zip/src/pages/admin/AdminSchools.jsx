import AdminCRUD from '../../components/admin/AdminCRUD'
import AdminForm from '../../components/admin/AdminForm'
import { School } from 'lucide-react'

const fields = [
  { key: 'name', label: 'School Name', type: 'text', required: true, placeholder: 'Enter school name' },
  { key: 'code', label: 'School Code', type: 'text', required: true, placeholder: 'e.g. ASC-001' },
  { key: 'photo', label: 'School Photo', type: 'file', folder: 'schools', description: 'Upload school photo' },
  { key: 'address', label: 'Address', type: 'textarea', rows: 3, placeholder: 'Full address' },
  { key: 'principal', label: 'Principal / Headmaster', type: 'text', placeholder: 'Name of principal' },
  { key: 'contact', label: 'Contact Number', type: 'tel', placeholder: '+91 12345 67890' },
  { key: 'email', label: 'Email', type: 'email', placeholder: 'school@email.com' },
  { key: 'teacherCount', label: 'Teacher Count', type: 'number', placeholder: '0' },
  { key: 'studentCount', label: 'Student Count', type: 'number', placeholder: '0' },
  { key: 'location', label: 'Location', type: 'text', placeholder: 'e.g. Dangachua, Odisha' }
]

export default function AdminSchools() {
  return (
    <AdminCRUD
      collection="schools"
      title="Schools"
      description="Manage the schools under your institution"
      searchFields={['name', 'code', 'principal']}
      defaultValues={{ teacherCount: 0, studentCount: 0, published: true }}
      renderCard={(school) => (
        <div className="flex items-center gap-3">
          {school.photo ? (
            <img src={school.photo} alt={school.name} className="w-12 h-12 rounded-lg object-cover" />
          ) : (
            <div className="w-12 h-12 rounded-lg bg-dark-700 flex items-center justify-center">
              <School className="h-6 w-6 text-gray-500" />
            </div>
          )}
          <div>
            <div className="text-white font-medium">{school.name}</div>
            <div className="text-sm text-neon-blue">{school.code}</div>
            <div className="text-xs text-gray-500">{school.principal}</div>
          </div>
        </div>
      )}
      formComponent={(props) => <AdminForm fields={fields} {...props} />}
    />
  )
}