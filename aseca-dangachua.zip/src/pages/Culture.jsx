import { PageHeader } from '../components/ui'
import { Music, Languages, BookOpen, Palette, Landmark, Sparkles, Heart, Users } from 'lucide-react'
import { useCollection } from '../hooks/useCollection'
import { where } from 'firebase/firestore'

export default function Culture() {
  const { data: cultureContent } = useCollection('culture', [where('published', '==', true)])

  const sections = [
    { icon: Languages, title: 'Santali Language', desc: 'The Santali language (Ol Chiki script) is one of India\'s scheduled languages, spoken by millions. We actively promote its learning and preservation.' },
    { icon: Music, title: 'Traditional Music', desc: 'From the rhythmic beats of the Tamak and Tumdak drums to the melodious flute, Santali music is deeply connected to nature and community life.' },
    { icon: Palette, title: 'Art & Craft', desc: 'Traditional Santali art includes intricate wall paintings, tribal motifs, and handcrafted items that reflect a rich cultural heritage.' },
    { icon: Landmark, title: 'Festivals', desc: 'Sohrai, Baha, and Karam are among the vibrant festivals celebrated with dance, music, and community gatherings throughout the year.' },
    { icon: BookOpen, title: 'Literature', desc: 'Santali literature includes rich oral traditions, folk tales, and modern writings that preserve and evolve the cultural narrative.' },
    { icon: Heart, title: 'Traditional Knowledge', desc: 'Indigenous knowledge of nature, medicine, and sustainable living is an invaluable part of Santali heritage that we honor and preserve.' }
  ]

  return (
    <div>
      <PageHeader
        icon={Music}
        title="Santali Culture"
        subtitle="Celebrating and preserving our rich cultural heritage"
      />

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="glass-strong p-8 md:p-12 text-center mb-12">
            <Sparkles className="h-12 w-12 text-neon-gold mx-auto mb-4" />
            <h2 className="text-2xl md:text-3xl font-bold neon-text mb-4">Our Cultural Heritage</h2>
            <p className="text-gray-300 leading-relaxed">
              The Santali community has a rich and vibrant culture that spans thousands of years. From our language and music to our festivals and art, every aspect of our heritage tells a story of resilience, harmony with nature, and deep community bonds. At BRANCH ASECA DANGACHUA, we believe education and culture go hand in hand - we nurture young minds while keeping our traditions alive.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {sections.map((section, i) => (
              <div key={section.title} className="glass-card p-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-gradient-to-br from-neon-blue/20 to-violet-500/20 text-neon-blue shrink-0">
                    <section.icon className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white text-lg mb-2">{section.title}</h3>
                    <p className="text-sm text-gray-400 leading-relaxed">{section.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {cultureContent.length > 0 && (
            <div className="mt-12">
              {cultureContent.map(item => (
                <div key={item.id} className="glass-card p-6 mb-6">
                  <h3 className="font-semibold text-white text-lg mb-3">{item.title}</h3>
                  <div className="text-gray-300 leading-relaxed" dangerouslySetInnerHTML={{ __html: item.content }} />
                </div>
              ))}
            </div>
          )}

          <div className="glass-strong p-8 text-center mt-12">
            <Users className="h-10 w-10 text-neon-emerald mx-auto mb-4" />
            <h3 className="font-semibold text-white text-xl mb-2">Join Us in Preserving Our Culture</h3>
            <p className="text-gray-400">
              We welcome students, parents, and community members to participate in our cultural programs and help keep our heritage alive for future generations.
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}