import { PageHeader, ProfileCard, Loader, EmptyState } from '../components/ui'
import { Users, Mail, Phone } from 'lucide-react'
import { useCollection } from '../hooks/useCollection'
import { where, orderBy } from 'firebase/firestore'

export default function ManagingBody() {
  const { data: members, loading } = useCollection('managingBody', [where('published', '==', true), orderBy('displayOrder', 'asc')])

  return (
    <div>
      <PageHeader
        icon={Users}
        title="Managing Body"
        subtitle="The leadership guiding our institution"
      />
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          {loading ? <Loader /> : members.length === 0 ? (
            <EmptyState title="No members yet" description="Managing body members will be listed here." />
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {members.map((member, i) => (
                <ProfileCard
                  key={member.id}
                  photo={member.photo}
                  name={member.name}
                  title={member.designation}
                  subtitle={member.qualification}
                  delay={i * 0.1}
                >
                  {member.biography && (
                    <p className="text-xs text-gray-400 mb-3 leading-relaxed">{member.biography}</p>
                  )}
                  <div className="flex flex-col gap-1 items-center text-xs text-gray-400">
                    {member.email && (
                      <span className="flex items-center gap-1"><Mail className="h-3 w-3" /> {member.email}</span>
                    )}
                    {member.phone && (
                      <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> {member.phone}</span>
                    )}
                  </div>
                </ProfileCard>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  )
}