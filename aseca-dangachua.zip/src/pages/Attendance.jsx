import { useState, useMemo } from 'react'
import { PageHeader, Loader, EmptyState, SearchBar } from '../components/ui'
import { ClipboardCheck, Calendar, CheckCircle2, XCircle, Clock, UserX } from 'lucide-react'
import { useCollection } from '../hooks/useCollection'
import { formatDate } from '../utils/helpers'

export default function Attendance() {
  const { data: attendance, loading } = useCollection('teacherAttendance')
  const [search, setSearch] = useState('')
  const [month, setMonth] = useState(() => {
    const d = new Date()
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
  })

  const filtered = useMemo(() => {
    return attendance.filter(record => {
      const q = search.toLowerCase()
      const matchesSearch = !q ||
        record.teacherName?.toLowerCase().includes(q) ||
        record.teacherId?.toLowerCase().includes(q)
      const recordDate = record.date ? new Date(record.date.seconds ? record.date.seconds * 1000 : record.date) : null
      const recordMonth = recordDate ? `${recordDate.getFullYear()}-${String(recordDate.getMonth() + 1).padStart(2, '0')}` : ''
      const matchesMonth = !month || recordMonth === month
      return matchesSearch && matchesMonth
    })
  }, [attendance, search, month])

  const stats = useMemo(() => {
    const total = filtered.length
    const present = filtered.filter(r => r.status === 'present').length
    const absent = filtered.filter(r => r.status === 'absent').length
    const leave = filtered.filter(r => r.status === 'leave').length
    const halfDay = filtered.filter(r => r.status === 'halfDay').length
    const percentage = total > 0 ? Math.round((present + halfDay * 0.5) / total * 100) : 0
    return { total, present, absent, leave, halfDay, percentage }
  }, [filtered])

  return (
    <div>
      <PageHeader
        icon={ClipboardCheck}
        title="Teacher Attendance"
        subtitle="Daily attendance records for our teaching staff"
      />

      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
            <div className="glass-card p-4 text-center">
              <div className="text-2xl font-bold text-white">{stats.total}</div>
              <div className="text-xs text-gray-400">Total Records</div>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="text-2xl font-bold text-neon-emerald">{stats.present}</div>
              <div className="text-xs text-gray-400">Present</div>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="text-2xl font-bold text-red-400">{stats.absent}</div>
              <div className="text-xs text-gray-400">Absent</div>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="text-2xl font-bold text-neon-gold">{stats.leave}</div>
              <div className="text-xs text-gray-400">Leave</div>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="text-2xl font-bold text-neon-blue">{stats.percentage}%</div>
              <div className="text-xs text-gray-400">Attendance Rate</div>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <SearchBar
              value={search}
              onChange={setSearch}
              placeholder="Search by teacher name..."
              className="flex-1"
            />
            <input
              type="month"
              value={month}
              onChange={(e) => setMonth(e.target.value)}
              className="neon-input md:w-48"
            />
          </div>

          {loading ? <Loader /> : filtered.length === 0 ? (
            <EmptyState title="No attendance records" description="Attendance records will appear here." />
          ) : (
            <div className="glass-strong overflow-hidden">
              <div className="table-responsive">
                <table className="table-glass">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Teacher</th>
                      <th>Status</th>
                      <th>Remarks</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map(record => (
                      <tr key={record.id}>
                        <td className="text-gray-300">{formatDate(record.date)}</td>
                        <td>
                          <div className="text-white font-medium">{record.teacherName}</div>
                          <div className="text-xs text-gray-500">{record.teacherId}</div>
                        </td>
                        <td>
                          {record.status === 'present' && <span className="pill pill-green"><CheckCircle2 className="h-3 w-3 mr-1" /> Present</span>}
                          {record.status === 'absent' && <span className="pill pill-red bg-red-500/10 text-red-400 border-red-500/30"><XCircle className="h-3 w-3 mr-1" /> Absent</span>}
                          {record.status === 'leave' && <span className="pill pill-gold"><Clock className="h-3 w-3 mr-1" /> Leave</span>}
                          {record.status === 'halfDay' && <span className="pill pill-violet"><UserX className="h-3 w-3 mr-1" /> Half Day</span>}
                        </td>
                        <td className="text-gray-400">{record.remarks || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}