import { useState, useMemo } from 'react'
import { PageHeader, Loader, EmptyState, Modal } from '../components/ui'
import { Images, X, ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react'
import { useCollection } from '../hooks/useCollection'
import { where } from 'firebase/firestore'

export default function Gallery() {
  const { data: albums, loading } = useCollection('galleryAlbums', [where('published', '==', true)])
  const { data: allImages } = useCollection('galleryImages')
  const [selectedAlbum, setSelectedAlbum] = useState(null)
  const [lightbox, setLightbox] = useState(null)

  const albumImages = useMemo(() => {
    if (!selectedAlbum) return []
    return allImages.filter(img => img.albumId === selectedAlbum.id)
  }, [selectedAlbum, allImages])

  const handlePrev = () => {
    if (!lightbox) return
    const idx = albumImages.findIndex(img => img.id === lightbox.id)
    setLightbox(albumImages[(idx - 1 + albumImages.length) % albumImages.length])
  }

  const handleNext = () => {
    if (!lightbox) return
    const idx = albumImages.findIndex(img => img.id === lightbox.id)
    setLightbox(albumImages[(idx + 1) % albumImages.length])
  }

  return (
    <div>
      <PageHeader
        icon={Images}
        title="Photo Gallery"
        subtitle="Moments from our institution's journey"
      />

      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          {loading ? <Loader /> : albums.length === 0 ? (
            <EmptyState title="No albums yet" description="Photo albums will appear here." />
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {albums.map((album, i) => (
                <div
                  key={album.id}
                  onClick={() => setSelectedAlbum(album)}
                  className="glass-card overflow-hidden card-hover cursor-pointer group"
                >
                  <div className="aspect-[4/3] overflow-hidden relative">
                    {album.coverImage ? (
                      <img
                        src={album.coverImage}
                        alt={album.title}
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center bg-dark-700">
                        <Images className="h-16 w-16 text-gray-600" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-dark-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="font-semibold text-white text-lg">{album.title}</h3>
                      {album.description && (
                        <p className="text-sm text-gray-300 line-clamp-1">{album.description}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Album modal */}
      <Modal open={!!selectedAlbum} onClose={() => setSelectedAlbum(null)} title={selectedAlbum?.title || 'Gallery'} size="xl">
        {selectedAlbum && (
          <div>
            {selectedAlbum.description && (
              <p className="text-gray-400 mb-6">{selectedAlbum.description}</p>
            )}
            {albumImages.length === 0 ? (
              <EmptyState title="No images in this album" description="Images will appear here when added." />
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {albumImages.map((img, i) => (
                  <div
                    key={img.id}
                    onClick={() => setLightbox(img)}
                    className="aspect-square rounded-xl overflow-hidden cursor-pointer group relative"
                  >
                    <img
                      src={img.url}
                      alt={img.caption || `Image ${i + 1}`}
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <ZoomIn className="h-8 w-8 text-white" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* Lightbox */}
      {lightbox && (
        <div className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center p-4" onClick={() => setLightbox(null)}>
          <button className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white" onClick={() => setLightbox(null)}>
            <X className="h-6 w-6" />
          </button>
          <button
            className="absolute left-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white"
            onClick={(e) => { e.stopPropagation(); handlePrev() }}
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <img
            src={lightbox.url}
            alt={lightbox.caption || 'Gallery image'}
            className="max-h-[90vh] max-w-[90vw] object-contain rounded-xl"
            onClick={(e) => e.stopPropagation()}
          />
          <button
            className="absolute right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white"
            onClick={(e) => { e.stopPropagation(); handleNext() }}
          >
            <ChevronRight className="h-6 w-6" />
          </button>
          {lightbox.caption && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white text-sm bg-black/60 px-4 py-2 rounded-full">
              {lightbox.caption}
            </div>
          )}
        </div>
      )}
    </div>
  )
}