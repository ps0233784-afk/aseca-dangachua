import { useState, useMemo } from 'react'
import { PageHeader, SearchBar, ProfileCard, Loader, EmptyState, Modal } from '../components/ui'
import { GraduationCap, BookOpen, School, Award, Mail, Phone, Briefcase } from 'lucide-react'
import { useCollection } from '../hooks/useCollection'
import { where } from 'firebase/firestore'

export default function Teachers() {
  const { data: teachers, loading } = useCollection('teachers', [where('published', '==', true)])
  const [search, setSearch] = useState('')
  const [subjectFilter, setSubjectFilter] = useState('all')
  const [schoolFilter, setSchoolFilter] = useState('all')
  const [selected, setSelected] = useState(null)

  const subjects = useMemo(() => {
    const set = new Set(teachers.map(t => t.subject).filter(Boolean))
    return ['all', ...set]
  }, [teachers])

  const schools = useMemo(() => {
    const set = new Set(teachers.map(t => t.school).filter(Boolean))
    return ['all', ...set]
  }, [teachers])

  const filtered = useMemo(() => {
    return teachers.filter(teacher => {
      const q = search.toLowerCase()
      const matchesSearch = !q ||
        teacher.name?.toLowerCase().includes(q) ||
        teacher.designation?.toLowerCase().includes(q) ||
        teacher.subject?.toLowerCase().includes(q)
      const matchesSubject = subjectFilter === 'all' || teacher.subject === subjectFilter
      const matchesSchool = schoolFilter === 'all' || teacher.school === schoolFilter
      return matchesSearch && matchesSubject && matchesSchool
    })
  }, [teachers, search, subjectFilter, schoolFilter])

  return (
    <div>
      <PageHeader
        icon={GraduationCap}
        title="Our Teachers"
        subtitle="Meet the dedicated educators shaping young minds"
      />

      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-4 mb-8">
            <SearchBar
              value={search}
              onChange={setSearch}
              placeholder="Search teachers..."
              className="md:col-span-1"
            />
            <select value={subjectFilter} onChange={(e) => setSubjectFilter(e.target.value)} className="neon-select">
              <option value="all">All Subjects</option>
              {subjects.filter(s => s !== 'all').map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select value={schoolFilter} onChange={(e) => setSchoolFilter(e.target.value)} className="neon-select">
              <option value="all">All Schools</option>
              {schools.filter(s => s !== 'all').map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          {loading ? <Loader /> : filtered.length === 0 ? (
            <EmptyState title="No teachers found" description="Try adjusting your search or filters." />
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((teacher, i) => (
                <ProfileCard
                  key={teacher.id}
                  photo={teacher.photo}
                  name={teacher.name}
                  title={teacher.designation}
                  subtitle={teacher.subject}
                  delay={i * 0.1}
                  onClick={() => setSelected(teacher)}
                >
                  <div className="flex flex-col gap-1 items-center text-xs text-gray-400">
                    {teacher.school && (
                      <span className="flex items-center gap-1"><School className="h-3 w-3" /> {teacher.school}</span>
                    )}
                    {teacher.experience && (
                      <span className="flex items-center gap-1"><Briefcase className="h-3 w-3" /> {teacher.experience} years experience</span>
                    )}
                  </div>
                </ProfileCard>
              ))}
            </div>
          )}
        </div>
      </section>

      <Modal open={!!selected} onClose={() => setSelected(null)} title="Teacher Profile">
        {selected && (
          <div className="text-center">
            <div className="w-32 h-32 mx-auto mb-4">
              {selected.photo ? (
                <img src={selected.photo} alt={selected.name} className="w-32 h-32 rounded-full object-cover border-2 border-neon-blue/40" />
              ) : (
                <div className="w-32 h-32 rounded-full bg-dark-700 flex items-center justify-center">
                  <GraduationCap className="h-12 w-12 text-gray-500" />
                </div>
              )}
            </div>
            <h3 className="font-semibold text-white text-xl mb-1">{selected.name}</h3>
            <div className="text-neon-blue font-medium mb-1">{selected.designation}</div>
            <div className="text-gray-400 text-sm mb-4">{selected.subject}</div>
            <div className="grid grid-cols-1 gap-3 text-left">
              {selected.qualification && (
                <div className="flex items-center gap-2 text-sm text-gray-300"><Award className="h-4 w-4 text-neon-gold" /> {selected.qualification}</div>
              )}
              {selected.school && (
                <div className="flex items-center gap-2 text-sm text-gray-300"><School className="h-4 w-4 text-neon-blue" /> {selected.school}</div>
              )}
              {selected.experience && (
                <div className="flex items-center gap-2 text-sm text-gray-300"><Briefcase className="h-4 w-4 text-neon-emerald" /> {selected.experience} years of experience</div>
              )}
              {selected.email && (
                <div className="flex items-center gap-2 text-sm text-gray-300"><Mail className="h-4 w-4 text-neon-magenta" /> {selected.email}</div>
              )}
              {selected.phone && (
                <div className="flex items-center gap-2 text-sm text-gray-300"><Phone className="h-4 w-4 text-neon-emerald" /> {selected.phone}</div>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}