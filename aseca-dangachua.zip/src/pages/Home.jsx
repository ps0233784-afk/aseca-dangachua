import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  GraduationCap, Users, School, Award, BookOpen, Newspaper, Images,
  Sparkles, ArrowRight, ChevronRight, Music, Landmark, Heart, Globe
} from 'lucide-react'
import { useSettings } from '../contexts/SettingsContext'
import { useCollection } from '../hooks/useCollection'
import { StatCard } from '../components/ui'
import { where, orderBy } from 'firebase/firestore'

const HERO_BG = 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c?q=80&w=1920&auto=format&fit=crop'

export default function Home() {
  const { settings, homepage } = useSettings()
  const [heroBg, setHeroBg] = useState(homepage?.hero?.background || HERO_BG)
  const [stats, setStats] = useState({ schools: 0, students: 0, teachers: 0, passRate: 0 })

  const { data: schoolsData } = useCollection('schools', [where('published', '==', true)])
  const { data: teachersData } = useCollection('teachers', [where('published', '==', true)])
  const { data: studentsData } = useCollection('students', [])
  const { data: newsData } = useCollection('news', [where('published', '==', true), orderBy('createdAt', 'desc')], false)
  const { data: galleryData } = useCollection('galleryAlbums', [where('published', '==', true)])

  useEffect(() => {
    if (homepage?.hero?.background) {
      setHeroBg(homepage.hero.background)
    }
  }, [homepage])

  useEffect(() => {
    if (homepage?.stats) {
      setStats(homepage.stats)
    } else {
      setStats({
        schools: schoolsData.length,
        students: studentsData.length,
        teachers: teachersData.length,
        passRate: 95
      })
    }
  }, [homepage, schoolsData, studentsData, teachersData])

  const hero = homepage?.hero || {
    heading: 'BRANCH ASECA DANGACHUA',
    tagline: 'Empowering Minds • Preserving Culture • Building the Future',
    button1Text: 'Explore Institution',
    button1Link: '/about',
    button2Text: 'View Results',
    button2Link: '/results'
  }

  const features = [
    { icon: Landmark, title: 'Quality Education', desc: 'Comprehensive curriculum fostering academic excellence and holistic development.', color: 'text-neon-blue' },
    { icon: Music, title: 'Cultural Preservation', desc: 'Celebrating and preserving the rich Santali heritage, language, and traditions.', color: 'text-neon-emerald' },
    { icon: Heart, title: 'Community Values', desc: 'Building strong character with respect, discipline, and community spirit.', color: 'text-neon-gold' },
    { icon: Globe, title: 'Modern Learning', desc: 'Digital classrooms and modern teaching methods for the future generation.', color: 'text-violet-400' }
  ]

  return (
    <div>
      {/* Hero Section */}
      <section className="relative min-h-[100vh] flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroBg})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-dark-900/80 via-dark-900/70 to-dark-900" />
        <div className="absolute inset-0 bg-gradient-to-r from-dark-900/60 to-transparent" />

        {/* Floating particles */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className="floating-particle"
              style={{
                width: Math.random() * 8 + 4 + 'px',
                height: Math.random() * 8 + 4 + 'px',
                left: Math.random() * 100 + '%',
                top: Math.random() * 100 + '%',
                background: ['#00d4ff', '#a855f7', '#00ff9d', '#ffd700'][i % 4],
                boxShadow: `0 0 20px ${['#00d4ff', '#a855f7', '#00ff9d', '#ffd700'][i % 4]}66`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${Math.random() * 5 + 5}s`
              }}
            />
          ))}
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-5xl mx-auto px-4 text-center pt-24 pb-16">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6">
              <Sparkles className="h-4 w-4 text-neon-gold" />
              <span className="text-sm text-gray-300">Welcome to our Institution</span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold font-display neon-text mb-6 leading-tight">
              {hero.heading}
            </h1>

            <p className="text-lg md:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto font-light">
              {hero.tagline}
            </p>

            <div className="flex flex-wrap gap-4 justify-center mb-12">
              <Link to={hero.button1Link || '/about'} className="neon-btn flex items-center gap-2 text-lg">
                {hero.button1Text || 'Explore Institution'}
                <ArrowRight className="h-5 w-5" />
              </Link>
              <Link to={hero.button2Link || '/results'} className="neon-btn-secondary flex items-center gap-2 text-lg">
                {hero.button2Text || 'View Results'}
                <ChevronRight className="h-5 w-5" />
              </Link>
            </div>

            {/* Quick links */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
              {[
                { icon: Users, label: 'Managing Body', link: '/managing-body' },
                { icon: School, label: 'Our Schools', link: '/schools' },
                { icon: GraduationCap, label: 'Student Portal', link: '/students' },
                { icon: Award, label: 'Results', link: '/results' }
              ].map((item, i) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                >
                  <Link
                    to={item.link}
                    className="glass-card p-4 flex flex-col items-center gap-2 hover:border-neon-blue/40"
                  >
                    <item.icon className="h-6 w-6 text-neon-blue" />
                    <span className="text-xs text-gray-300">{item.label}</span>
                  </Link>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronRight className="h-6 w-6 text-gray-400 rotate-90" />
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard icon={School} label="Schools" value={stats.schools} color="blue" delay={0} />
            <StatCard icon={Users} label="Students" value={stats.students} color="emerald" delay={0.1} />
            <StatCard icon={GraduationCap} label="Teachers" value={stats.teachers} color="violet" delay={0.2} />
            <StatCard icon={Award} label="Pass Rate" value={`${stats.passRate}%`} color="gold" delay={0.3} />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-gradient-animated">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="section-title neon-text">Why Choose Us</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">Education rooted in culture, building bright futures</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card p-6"
              >
                <div className={`p-3 rounded-xl bg-white/5 inline-block mb-4 ${feature.color}`}>
                  <feature.icon className="h-8 w-8" />
                </div>
                <h3 className="font-semibold text-white text-lg mb-2">{feature.title}</h3>
                <p className="text-sm text-gray-400">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About preview */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="section-title neon-text mb-6">About Our Institution</h2>
            <div className="text-gray-300 leading-relaxed space-y-4" dangerouslySetInnerHTML={{
              __html: homepage?.about?.content || `
                <p>BRANCH ASECA DANGACHUA is dedicated to providing quality education while preserving the rich Santali cultural heritage of Odisha.</p>
                <p>We combine modern educational practices with traditional values to nurture well-rounded individuals ready for the future.</p>
              `
            }} />
            <Link to="/about" className="neon-btn inline-flex items-center gap-2 mt-6">
              Learn More <ArrowRight className="h-4 w-4" />
            </Link>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-card p-6"
          >
            <div className="aspect-[4/3] rounded-xl overflow-hidden bg-dark-700 flex items-center justify-center">
              {homepage?.about?.image ? (
                <img src={homepage.about.image} alt="About" className="h-full w-full object-cover" />
              ) : (
                <div className="text-center p-8">
                  <Landmark className="h-16 w-16 text-neon-blue mx-auto mb-4" />
                  <p className="text-gray-400">Institution building image</p>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </section>

      {/* News preview */}
      <section className="py-16 px-4 bg-gradient-animated">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="section-title neon-text">Latest News</h2>
            <Link to="/news" className="text-neon-blue hover:underline text-sm flex items-center gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {newsData.slice(0, 3).length > 0 ? newsData.slice(0, 3).map((news, i) => (
              <motion.div
                key={news.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card overflow-hidden"
              >
                {news.thumbnail && (
                  <img src={news.thumbnail} alt={news.title} className="h-48 w-full object-cover" />
                )}
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="pill pill-blue">{news.category || 'News'}</span>
                    <span className="text-xs text-gray-500">{news.date ? new Date(news.date).toLocaleDateString() : ''}</span>
                  </div>
                  <h3 className="font-semibold text-white mb-2 line-clamp-2">{news.title}</h3>
                  <p className="text-sm text-gray-400 line-clamp-3" dangerouslySetInnerHTML={{ __html: news.content || '' }} />
                </div>
              </motion.div>
            )) : (
              <div className="col-span-3 text-center text-gray-500 py-8">No news yet. Check back soon!</div>
            )}
          </div>
        </div>
      </section>

      {/* Gallery preview */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="section-title neon-text">Photo Gallery</h2>
            <Link to="/gallery" className="text-neon-blue hover:underline text-sm flex items-center gap-1">
              View Gallery <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {galleryData.slice(0, 4).map((album, i) => (
              <motion.div
                key={album.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card overflow-hidden aspect-square"
              >
                {album.coverImage ? (
                  <img src={album.coverImage} alt={album.title} className="h-full w-full object-cover card-hover" />
                ) : (
                  <div className="h-full w-full flex items-center justify-center bg-dark-700">
                    <Images className="h-12 w-12 text-gray-600" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto glass-strong p-8 md:p-12 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-neon-blue via-violet-500 to-neon-magenta" />
          <BookOpen className="h-12 w-12 text-neon-blue mx-auto mb-4" />
          <h2 className="text-3xl md:text-4xl font-bold neon-text mb-4">Begin Your Educational Journey</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Join our institution and experience quality education combined with rich cultural heritage. Let's build a brighter future together.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link to="/contact" className="neon-btn">Contact Us</Link>
            <Link to="/students" className="neon-btn-secondary">Student Portal</Link>
          </div>
        </div>
      </section>
    </div>
  )
}