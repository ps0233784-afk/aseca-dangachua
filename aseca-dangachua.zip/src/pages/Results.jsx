import { useState } from 'react'
import { PageHeader, Loader, EmptyState } from '../components/ui'
import { Award, Search, Printer, Download, UserSquare, CheckCircle2 } from 'lucide-react'
import { useCollection } from '../hooks/useCollection'
import { calculatePercentage, calculateGrade } from '../utils/helpers'
import { QRCodeSVG } from 'qrcode.react'

export default function Results() {
  const { data: results, loading } = useCollection('results')
  const { data: resultSubjects } = useCollection('resultSubjects')
  const [searchTerm, setSearchTerm] = useState('')
  const [searched, setSearched] = useState(false)
  const [foundResult, setFoundResult] = useState(null)

  const handleSearch = (e) => {
    e.preventDefault()
    setSearched(true)
    const q = searchTerm.trim().toLowerCase()
    if (!q) {
      setFoundResult(null)
      return
    }

    const result = results.find(r =>
      r.rollNumber?.toLowerCase() === q ||
      r.studentId?.toLowerCase() === q ||
      r.studentName?.toLowerCase().includes(q)
    )

    if (result) {
      const subjects = resultSubjects.filter(s => s.resultId === result.id)
      const totalMarks = subjects.reduce((sum, s) => sum + (s.marks || 0), 0)
      const fullMarks = subjects.reduce((sum, s) => sum + (s.fullMarks || 100), 0)
      const percentage = calculatePercentage(totalMarks, fullMarks)
      setFoundResult({ ...result, subjects, totalMarks, fullMarks, percentage, grade: calculateGrade(percentage) })
    } else {
      setFoundResult(null)
    }
  }

  const handlePrint = () => {
    window.print()
  }

  const handleDownload = () => {
    if (!foundResult) return
    const data = {
      student: foundResult.studentName,
      rollNumber: foundResult.rollNumber,
      studentId: foundResult.studentId,
      exam: foundResult.examName,
      class: foundResult.class,
      subjects: foundResult.subjects.map(s => ({ subject: s.subject, marks: s.marks, fullMarks: s.fullMarks })),
      total: foundResult.totalMarks,
      fullMarks: foundResult.fullMarks,
      percentage: foundResult.percentage,
      grade: foundResult.grade
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `result-${foundResult.rollNumber}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div>
      <PageHeader
        icon={Award}
        title="Result Portal"
        subtitle="Search your results by roll number, student ID, or name"
      />

      <section className="py-12 px-4">
        <div className="max-w-3xl mx-auto">
          <form onSubmit={handleSearch} className="glass-strong p-6 mb-8">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Enter roll number, student ID, or name"
                  className="neon-input !pl-10"
                />
              </div>
              <button type="submit" className="neon-btn flex items-center justify-center gap-2">
                <Search className="h-4 w-4" /> Search
              </button>
            </div>
          </form>

          {loading ? <Loader /> : searched && !foundResult ? (
            <EmptyState
              title="No result found"
              description="Please check your roll number, student ID, or name and try again."
            />
          ) : foundResult ? (
            <div className="glass-strong p-6 md:p-8" id="marksheet">
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold neon-text mb-2">Marksheet</h2>
                <div className="text-sm text-gray-400">{foundResult.examName}</div>
              </div>

              <div className="flex items-center gap-4 mb-6">
                <div className="w-20 h-20 rounded-full overflow-hidden bg-dark-700 flex items-center justify-center shrink-0">
                  {foundResult.photo ? (
                    <img src={foundResult.photo} alt={foundResult.studentName} className="h-full w-full object-cover" />
                  ) : (
                    <UserSquare className="h-10 w-10 text-gray-500" />
                  )}
                </div>
                <div>
                  <h3 className="font-semibold text-white text-lg">{foundResult.studentName}</h3>
                  <div className="text-sm text-gray-400">Roll: {foundResult.rollNumber}</div>
                  <div className="text-sm text-gray-400">ID: {foundResult.studentId}</div>
                  <div className="text-sm text-gray-400">Class: {foundResult.class}</div>
                </div>
              </div>

              <div className="overflow-x-auto mb-6">
                <table className="table-glass">
                  <thead>
                    <tr>
                      <th>Subject</th>
                      <th>Full Marks</th>
                      <th>Marks Obtained</th>
                    </tr>
                  </thead>
                  <tbody>
                    {foundResult.subjects.map((subject, i) => (
                      <tr key={i}>
                        <td className="text-white">{subject.subject}</td>
                        <td className="text-gray-400">{subject.fullMarks || 100}</td>
                        <td className="text-neon-emerald font-semibold">{subject.marks || 0}</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 border-white/20">
                      <td className="text-white font-semibold">Total</td>
                      <td className="text-gray-400 font-semibold">{foundResult.fullMarks}</td>
                      <td className="text-neon-emerald font-bold">{foundResult.totalMarks}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="text-center p-3 rounded-xl bg-white/5">
                  <div className="text-2xl font-bold text-neon-blue">{foundResult.percentage}%</div>
                  <div className="text-xs text-gray-400">Percentage</div>
                </div>
                <div className="text-center p-3 rounded-xl bg-white/5">
                  <div className="text-2xl font-bold text-neon-gold">{foundResult.grade}</div>
                  <div className="text-xs text-gray-400">Grade</div>
                </div>
                <div className="text-center p-3 rounded-xl bg-white/5">
                  <div className="text-2xl font-bold text-neon-emerald">{foundResult.rank || '—'}</div>
                  <div className="text-xs text-gray-400">Rank</div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex gap-3 no-print">
                  <button onClick={handlePrint} className="neon-btn-secondary flex items-center gap-2 text-sm !py-2">
                    <Printer className="h-4 w-4" /> Print
                  </button>
                  <button onClick={handleDownload} className="neon-btn-secondary flex items-center gap-2 text-sm !py-2">
                    <Download className="h-4 w-4" /> Download
                  </button>
                </div>
                <div className="text-center">
                  <QRCodeSVG value={`${foundResult.studentId}-${foundResult.rollNumber}`} size={80} />
                  <div className="text-[10px] text-gray-500 mt-1">Scan to verify</div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center text-gray-500 py-8">
              <CheckCircle2 className="h-12 w-12 mx-auto mb-4 text-gray-600" />
              <p>Enter your details above to view your results.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}