import { useState, useMemo } from 'react'
import { PageHeader, Loader, EmptyState, SearchBar, Modal } from '../components/ui'
import { FileSpreadsheet, Calendar, Clock, MapPin, BookOpen, Download } from 'lucide-react'
import { useCollection } from '../hooks/useCollection'
import { where, orderBy } from 'firebase/firestore'
import { formatDate } from '../utils/helpers'

export default function Examinations() {
  const { data: exams, loading } = useCollection('examinations', [where('published', '==', true), orderBy('date', 'desc')])
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)

  const filtered = useMemo(() => {
    return exams.filter(exam => {
      const q = search.toLowerCase()
      return !q ||
        exam.name?.toLowerCase().includes(q) ||
        exam.class?.toLowerCase().includes(q) ||
        exam.subject?.toLowerCase().includes(q)
    })
  }, [exams, search])

  return (
    <div>
      <PageHeader
        icon={FileSpreadsheet}
        title="Examinations"
        subtitle="Exam schedules, timetables, and important information"
      />

      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <SearchBar
              value={search}
              onChange={setSearch}
              placeholder="Search exams by name, class, subject..."
            />
          </div>

          {loading ? <Loader /> : filtered.length === 0 ? (
            <EmptyState title="No examinations found" description="Exam schedules will appear here." />
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((exam, i) => (
                <div
                  key={exam.id}
                  onClick={() => setSelected(exam)}
                  className="glass-card p-6 card-hover cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="p-3 rounded-xl bg-neon-blue/10 text-neon-blue">
                      <FileSpreadsheet className="h-6 w-6" />
                    </div>
                    <span className="pill pill-blue">{exam.class || 'All Classes'}</span>
                  </div>
                  <h3 className="font-semibold text-white text-lg mb-2">{exam.name}</h3>
                  <div className="space-y-2 text-sm text-gray-400">
                    {exam.date && (
                      <div className="flex items-center gap-2"><Calendar className="h-4 w-4 text-neon-blue" /> {formatDate(exam.date)}</div>
                    )}
                    {exam.time && (
                      <div className="flex items-center gap-2"><Clock className="h-4 w-4 text-neon-emerald" /> {exam.time}</div>
                    )}
                    {exam.subject && (
                      <div className="flex items-center gap-2"><BookOpen className="h-4 w-4 text-neon-gold" /> {exam.subject}</div>
                    )}
                    {exam.venue && (
                      <div className="flex items-center gap-2"><MapPin className="h-4 w-4 text-violet-400" /> {exam.venue}</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <Modal open={!!selected} onClose={() => setSelected(null)} title="Examination Details">
        {selected && (
          <div>
            <div className="mb-6">
              <h3 className="font-semibold text-white text-xl mb-2">{selected.name}</h3>
              <span className="pill pill-blue">{selected.class || 'All Classes'}</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              {selected.date && (
                <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
                  <Calendar className="h-5 w-5 text-neon-blue" />
                  <div>
                    <div className="text-xs text-gray-500">Date</div>
                    <div className="text-sm text-white">{formatDate(selected.date)}</div>
                  </div>
                </div>
              )}
              {selected.time && (
                <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
                  <Clock className="h-5 w-5 text-neon-emerald" />
                  <div>
                    <div className="text-xs text-gray-500">Time</div>
                    <div className="text-sm text-white">{selected.time}</div>
                  </div>
                </div>
              )}
              {selected.subject && (
                <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
                  <BookOpen className="h-5 w-5 text-neon-gold" />
                  <div>
                    <div className="text-xs text-gray-500">Subject</div>
                    <div className="text-sm text-white">{selected.subject}</div>
                  </div>
                </div>
              )}
              {selected.venue && (
                <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
                  <MapPin className="h-5 w-5 text-violet-400" />
                  <div>
                    <div className="text-xs text-gray-500">Venue</div>
                    <div className="text-sm text-white">{selected.venue}</div>
                  </div>
                </div>
              )}
            </div>
            {selected.instructions && (
              <div className="mb-6">
                <h4 className="font-semibold text-white mb-2">Instructions</h4>
                <div className="text-sm text-gray-300 leading-relaxed" dangerouslySetInnerHTML={{ __html: selected.instructions }} />
              </div>
            )}
            {selected.admitCardUrl && (
              <a
                href={selected.admitCardUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="neon-btn inline-flex items-center gap-2"
              >
                <Download className="h-4 w-4" /> Download Admit Card
              </a>
            )}
          </div>
        )}
      </Modal>
    </div>
  )
}