import { PageHeader } from '../components/ui'
import { Info, Target, Eye, Heart } from 'lucide-react'
import { useSettings } from '../contexts/SettingsContext'

export default function About() {
  const { homepage } = useSettings()

  const values = [
    { icon: Target, title: 'Our Mission', desc: 'To provide accessible, quality education that empowers students with knowledge, skills, and values while nurturing their cultural identity.' },
    { icon: Eye, title: 'Our Vision', desc: 'To be a leading educational institution that produces confident, capable, and culturally proud citizens contributing to society and nation.' },
    { icon: Heart, title: 'Our Values', desc: 'Respect for all cultures and people, integrity, excellence, community service, and preservation of the Santali heritage.' }
  ]

  return (
    <div>
      <PageHeader
        icon={Info}
        title="About Us"
        subtitle="Our story, mission, and commitment to education and culture"
      />

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="glass-strong p-8 md:p-12">
            <h2 className="section-title neon-text mb-6">Our Institution</h2>
            <div
              className="text-gray-300 leading-relaxed space-y-4"
              dangerouslySetInnerHTML={{
                __html: homepage?.about?.content || `
                  <p>BRANCH ASECA DANGACHUA is a premier educational institution dedicated to the holistic development of students. We believe education goes beyond textbooks - it shapes character, builds communities, and preserves culture.</p>
                  <p>Our institution proudly serves the Santali community and surrounding areas, combining modern educational excellence with respect for traditional knowledge and cultural heritage.</p>
                  <p>We are committed to creating an environment where every student can discover their potential, develop critical thinking, and grow into responsible citizens.</p>
                `
              }}
            />
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-gradient-animated">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="section-title neon-text">Our Mission & Vision</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {values.map((value) => (
              <div key={value.title} className="glass-card p-6 text-center">
                <div className="inline-flex p-3 rounded-xl bg-white/5 mb-4 text-neon-blue">
                  <value.icon className="h-8 w-8" />
                </div>
                <h3 className="font-semibold text-white text-lg mb-2">{value.title}</h3>
                <p className="text-sm text-gray-400">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}