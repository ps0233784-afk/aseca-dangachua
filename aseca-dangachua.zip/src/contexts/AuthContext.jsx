import { createContext, useContext, useEffect, useState } from 'react'
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail
} from 'firebase/auth'
import { auth } from '../firebase/auth'
import { getUserByEmail, addDocument, updateDocument } from '../services/firestoreService'
import { logAudit } from '../services/auditService'

const AuthContext = createContext()

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used within AuthProvider')
  return context
}

const DEFAULT_HOMEPAGE = {
  hero: {
    heading: 'BRANCH ASECA DANGACHUA',
    tagline: 'Empowering Minds • Preserving Culture • Building the Future',
    background: '',
    button1Text: 'Explore Institution',
    button1Link: '/about',
    button2Text: 'View Results',
    button2Link: '/results'
  },
  stats: {
    schools: 0,
    students: 0,
    teachers: 0,
    passRate: 0
  },
  about: {
    title: 'About Our Institution',
    content: ''
  },
  features: [],
  footerText: '© 2025 BRANCH ASECA DANGACHUA. All rights reserved.'
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [userData, setUserData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const snapshot = await getUserByEmail(firebaseUser.email)
          let data = null
          if (!snapshot.empty) {
            data = snapshot.docs[0].data()
            data.id = snapshot.docs[0].id
            // Re-create user doc if missing, default to viewer
          } else {
            data = {
              email: firebaseUser.email,
              name: firebaseUser.displayName || firebaseUser.email.split('@')[0],
              role: 'viewer',
              active: true
            }
            try {
              const ref = await addDocument('users', data)
              data.id = ref.id
            } catch (e) {
              console.warn('Could not create user profile', e)
            }
          }
          setUser(firebaseUser)
          setUserData(data)
          setIsAdmin(['superadmin', 'admin', 'editor'].includes(data?.role))
        } catch (error) {
          console.error('Error loading user data:', error)
          setUser(firebaseUser)
          setUserData({ email: firebaseUser.email, role: 'viewer' })
          setIsAdmin(false)
        }
      } else {
        setUser(null)
        setUserData(null)
        setIsAdmin(false)
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const login = async (email, password) => {
    const userCredential = await signInWithEmailAndPassword(auth, email, password)
    const user = userCredential.user

    // Check if user has admin role in Firestore
    const snapshot = await getUserByEmail(email)
    let role = 'viewer'
    let userDocId = null

    if (!snapshot.empty) {
      const data = snapshot.docs[0].data()
      role = data.role || 'viewer'
      userDocId = snapshot.docs[0].id
      if (!data.active) {
        await signOut(auth)
        throw new Error('Account is disabled. Contact administrator.')
      }
    }

    if (!['superadmin', 'admin', 'editor'].includes(role)) {
      await signOut(auth)
      throw new Error('You do not have admin access to this dashboard.')
    }

    await logAudit({ email, role }, 'LOGIN')

    // Get fresh user data
    const currentUserRes = await getUserByEmail(email)
    if (!currentUserRes.empty) {
      const data = currentUserRes.docs[0].data()
      data.id = currentUserRes.docs[0].id
      setUserData(data)
    }

    return { user, role }
  }

  const register = async (email, password, name) => {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    await addDocument('users', {
      email,
      name,
      role: 'viewer',
      active: true,
      createdAt: new Date().toISOString()
    })
    await logAudit({ email, role: 'viewer' }, 'REGISTER')
    return userCredential.user
  }

  const logout = async () => {
    await logAudit(userData, 'LOGOUT')
    await signOut(auth)
  }

  const resetPassword = (email) => {
    return sendPasswordResetEmail(auth, email)
  }

  const updateUserRole = async (userId, role) => {
    await updateDocument('users', userId, { role })
    await logAudit(userData, 'UPDATE_USER_ROLE', { userId, role })
  }

  const value = {
    user,
    userData,
    loading,
    isAdmin,
    login,
    register,
    logout,
    resetPassword,
    updateUserRole,
    setUserData
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}