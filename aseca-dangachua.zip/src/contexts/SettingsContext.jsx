import { createContext, useContext, useEffect, useState } from 'react'
import { getDocument, updateDocument, addDocument, getCollection } from '../services/firestoreService'

const SettingsContext = createContext()

export const useSettings = () => {
  const context = useContext(SettingsContext)
  if (!context) throw new Error('useSettings must be used within SettingsProvider')
  return context
}

const DEFAULT_SETTINGS = {
  institutionName: 'BRANCH ASECA DANGACHUA',
  tagline: 'Empowering Minds • Preserving Culture • Building the Future',
  logo: '',
  favicon: '',
  primaryColor: '#00d4ff',
  secondaryColor: '#a855f7',
  accentColor: '#00ff9d',
  contactEmail: 'contact@asecadangachua.edu.in',
  contactPhone: '+91 12345 67890',
  address: 'Dangachua, Odisha, India',
  mapEmbed: '',
  footerText: '© 2025 BRANCH ASECA DANGACHUA. All rights reserved.',
  socialLinks: {
    facebook: '',
    instagram: '',
    twitter: '',
    youtube: ''
  }
}

export const SettingsProvider = ({ children }) => {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS)
  const [homepage, setHomepage] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    try {
      // Try to load website settings
      const settingsSnap = await getCollection('settings')
      if (!settingsSnap.empty) {
        const data = settingsSnap.docs[0].data()
        data.id = settingsSnap.docs[0].id
        setSettings({ ...DEFAULT_SETTINGS, ...data })
      }

      // Try homepage settings
      const homepageSnap = await getCollection('homepage')
      if (!homepageSnap.empty) {
        const data = homepageSnap.docs[0].data()
        data.id = homepageSnap.docs[0].id
        setHomepage(data)
      }
    } catch (error) {
      console.warn('Could not load settings:', error)
    } finally {
      setLoading(false)
    }
  }

  const saveSettings = async (data) => {
    try {
      const snap = await getCollection('settings')
      if (!snap.empty) {
        await updateDocument('settings', snap.docs[0].id, data)
      } else {
        await addDocument('settings', data)
      }
      setSettings({ ...settings, ...data })
      return { success: true }
    } catch (error) {
      console.error('Error saving settings:', error)
      return { success: false, error: error.message }
    }
  }

  const saveHomepage = async (data) => {
    try {
      const snap = await getCollection('homepage')
      if (!snap.empty) {
        await updateDocument('homepage', snap.docs[0].id, data)
      } else {
        await addDocument('homepage', data)
      }
      setHomepage(data)
      return { success: true }
    } catch (error) {
      console.error('Error saving homepage:', error)
      return { success: false, error: error.message }
    }
  }

  const value = {
    settings,
    homepage,
    loading,
    saveSettings,
    saveHomepage,
    reloadSettings: loadSettings
  }

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>
}