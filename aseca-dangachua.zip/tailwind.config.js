/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      colors: {
        neon: {
          blue: '#00d4ff',
          cyan: '#00f0ff',
          emerald: '#00ff9d',
          violet: '#a855f7',
          magenta: '#ff00e5',
          gold: '#ffd700'
        },
        dark: {
          900: '#060a14',
          800: '#0a1120',
          700: '#0f1a2e'
        }
      },
      backdropBlur: {
        xs: '2px'
      },
      fontFamily: {
        display: ['Poppins', 'sans-serif'],
        body: ['Inter', 'sans-serif']
      },
      animation: {
        float: 'float 6s ease-in-out infinite',
        'float-slow': 'float 9s ease-in-out infinite',
        'gradient-x': 'gradient-x 8s ease infinite',
        'pulse-glow': 'pulse-glow 3s ease-in-out infinite',
        'spin-slow': 'spin 12s linear infinite'
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' }
        },
        'gradient-x': {
          '0%, 100%': { backgroundPosition: '0% 50%' },
          '50%': { backgroundPosition: '100% 50%' }
        },
        'pulse-glow': {
          '0%, 100%': { boxShadow: '0 0 20px rgba(0, 212, 255, 0.3)' },
          '50%': { boxShadow: '0 0 40px rgba(0, 212, 255, 0.6)' }
        }
      },
      boxShadow: {
        'neon-blue': '0 0 20px rgba(0, 212, 255, 0.3)',
        'neon-cyan': '0 0 20px rgba(0, 240, 255, 0.3)',
        'neon-emerald': '0 0 20px rgba(0, 255, 157, 0.3)',
        'neon-violet': '0 0 20px rgba(168, 85, 247, 0.3)',
        'neon-magenta': '0 0 20px rgba(255, 0, 229, 0.3)',
        'neon-gold': '0 0 20px rgba(255, 215, 0, 0.3)'
      }
    }
  },
  plugins: []
}